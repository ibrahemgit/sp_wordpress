<?php

/*
	==========================================
	 admin-page Inc
	==========================================
*/

function sp_admin_script($hook){
    echo $hook;
    if(str_contains( $hook , 'seoplus-settings_page_seoplus' ) || str_contains( $hook , 'toplevel_page_seoplus' ) || str_contains( $hook , 'page_seoplus_' ) || str_contains( 'toplevel_page_seoplus_adminpage', $hook ) || str_contains( 'widgets.php', $hook ) ){
        wp_register_style('adminstyle', get_template_directory_uri() . '/css/admin-style.css',array(),'1.0.0','all');
        wp_enqueue_style('adminstyle');
    
        wp_enqueue_media();
    
        wp_register_script('adminscripts', get_template_directory_uri() . '/js/admin-scripts.js',array('jquery'),'1.0.0',true);
        wp_enqueue_script('adminscripts');
    }else{
        return;
    }

}
add_action( 'admin_enqueue_scripts', 'sp_admin_script' );