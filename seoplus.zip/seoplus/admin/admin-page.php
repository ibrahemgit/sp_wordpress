<?php

/*
	==========================================
	 admin-page
	==========================================
*/

require_once( get_template_directory() . '/admin/admin_function.php');


/* get options */

function seoplus_add_adminpage() {
    // new page
    add_menu_page(
        'Seoplus Settings',
        'Seoplus Settings',
        'manage_options',
        'seoplus_adminpage',
        'seoplus_settings_page',
        // get_template_directory_uri() . '/icons/icon.png', 110
    );
    
    add_submenu_page(
        'seoplus_adminpage',
        'Main Settings', 
        'Main Settings', 
        'manage_options', 
        'seoplus_adminpage', 
        'seoplus_settings_page'
    );

    add_submenu_page(
        'seoplus_adminpage',
        'Seoplus Main Settings', 
        'Seoplus Main Settings', 
        'manage_options', 
        'seoplus_main_settings', 
        'seoplus_main_settings'
    );

    add_submenu_page(
        'seoplus_adminpage',
        'Seoplus Header Settings', 
        'Seoplus Header Settings', 
        'manage_options', 
        'seoplus_header_settings', 
        'seoplus_header_settings'
    );

    add_submenu_page(
        'seoplus_adminpage',
        'Seoplus Aside Settings', 
        'Seoplus Aside Settings', 
        'manage_options', 
        'seoplus_aside_settings', 
        'seoplus_aside_settings'
    );

    add_submenu_page(
        'seoplus_adminpage',
        'Seoplus Last Posts Settings', 
        'Seoplus Last Posts Settings', 
        'manage_options', 
        'seoplus_last_posts_settings', 
        'seoplus_last_posts_settings'
    );

    add_submenu_page(
        'seoplus_adminpage',
        'Seoplus Redirect Page Settings', 
        'Seoplus Redirect Page Settings', 
        'manage_options', 
        'seoplus_redirect_settings', 
        'seoplus_redirect_settings'
    );

    add_submenu_page(
        'seoplus_adminpage',
        'Seoplus Post Features Settings', 
        'Seoplus Post Features Settings', 
        'manage_options', 
        'seoplus_postFeatures_settings', 
        'seoplus_postFeatures_settings'
    );

    add_submenu_page(
        'seoplus_adminpage',
        'Seoplus Post Custom Settings', 
        'Seoplus Post Custom Settings', 
        'manage_options', 
        'seoplus_postCustom_settings', 
        'seoplus_postCustom_settings'
    );

    add_submenu_page(
        'seoplus_adminpage',
        'Seoplus min Colors Settings', 
        'Seoplus min Colors Settings', 
        'manage_options', 
        'seoplus_minColor_settings', 
        'seoplus_minColor_settings'
    );




    // new page ADS
    add_menu_page(
        'Seoplus ADS',
        'Seoplus ADS',
        'manage_options',
        'seoplus_ads',
        'seoplus_settings_ads',
        // get_template_directory_uri() . '/icons/icon.png', 110
    );
    add_submenu_page(
        'seoplus_ads',
        'Seoplus main Ads', 
        'Seoplus main Ads', 
        'manage_options', 
        'seoplus_ads', 
        'seoplus_settings_ads'
    );

    add_submenu_page(
        'seoplus_ads',
        'Seoplus author Ads', 
        'Seoplus author Ads', 
        'manage_options', 
        'seoplus_author_ads', 
        'seoplus_author_ads'
    );

    add_submenu_page(
        'seoplus_ads',
        'Seoplus Ads Text', 
        'Seoplus Ads Text', 
        'manage_options', 
        'seoplus_ads_text', 
        'seoplus_ads_text'
    );



    // Users Mangment
    add_menu_page(
        'Users Mangment',
        'Users Mangment',
        'manage_options',
        'seoplus_users_mangment',
        'seoplus_users_mangment',
        // get_template_directory_uri() . '/icons/icon.png', 110
    );
    
    add_submenu_page(
        'seoplus_users_mangment',
        'Users Mangment', 
        'Users Mangment', 
        'manage_options', 
        'seoplus_users_mangment', 
        'seoplus_users_mangment'
    );
    
    add_submenu_page(
        'seoplus_users_mangment',
        'Users white list', 
        'Users white list', 
        'manage_options', 
        'seoplus_users_mangment_white_list', 
        'seoplus_users_mangment_white_list'
    );

    // activate
    add_action('admin_init', 'sp_custom_setting');
    add_action('admin_init', 'sp_theme_ads_setting');
    add_action('admin_init', 'sp_theme_users_mangment');
}
add_action( 'admin_menu', 'seoplus_add_adminpage' );


function sp_theme_users_mangment(){
        # Users Mangment white_list
        add_settings_section(
            'sp_users_mangment_white_list',
            'ادارة المستخدمين',
            'sp_settings_option',
            'seoplus_users_mangment_white_list',
            array(
                'before_section' => '<div class="settings_group active" id="sp_users_mangment_white_list">',
                'after_section' => '</div>',
            )
        );
        # Users Mangment white_list
        setting_fields(
            'sp_users_mangment_white_list',
            array(
                
            ),
            'seoplus-users-mangment-white-list-group',
            'sp_users_mangment_white_list',
            'seoplus_users_mangment_white_list'
        );




        # Users Mangment
        add_settings_section(
            'sp_users_mangment',
            'ادارة المستخدمين',
            'sp_settings_option',
            'seoplus_users_mangment',
            array(
                'before_section' => '<div class="settings_group active" id="sp_users_mangment">',
                'after_section' => '</div>',
            )
        );

        # Users Mangment
        setting_fields(
            'sp_users_mangment',
            array(
                array(
                    'type'      => 'switch',
                    'name'      => 'users_mangment_is_active',
                    'title'     => 'تفعيل نظام ادارة الاعضاء',
                ),
                array(
                    'type'      => 'switch',
                    'name'      => 'users_mangment_tapel',
                    'title'     => 'ااظهار الروابط التي بالمقالات',
                ),
            ),
            'seoplus-users-mangment-group',
            'sp_users_mangment',
            'seoplus_users_mangment'
        );
}



function sp_theme_ads_setting(){


        # theme Ads Text
        add_settings_section(
            'sp_ads_txt',
            'ادس تكست',
            'sp_settings_option',
            'seoplus_settings_ads_text',
            array(
                'before_section' => '<div class="settings_group active" id="sp_ads_txt">',
                'after_section' => '</div>',
            )
        );

        

        # theme Ads Text
        setting_fields(
            'sp_ads_txt',
            array(
                array(
                    'type'      => 'switch',
                    'name'      => 'ads_text_active',
                    'title'     => 'تفعيل ملف ادس تكست',
                ),
                array(
                    'type'      => 'textarea',
                    'name'      => 'ads_text_area',
                    'title'     => 'ملف ادس تكست',
                ),
            ),
            'seoplus-ads-text-group',
            'sp_ads_txt',
            'seoplus_settings_ads_text'
        );

        # theme Ads Settings
        add_settings_section(
            'sp_theme_ads',
            'اضف اعلان جديد',
            'sp_settings_option',
            'seoplus_settings_ads',
            array(
                'before_section' => '<div class="settings_group active" id="sp_theme_ads">',
                'after_section' => '</div>',
            )
        );
    
        # theme Ads fields
        setting_fields(
            'sp_theme_ads',
            array(
                array(
                    'type'      => 'switch',
                    'name'      => 'adsactive',
                    'title'     => 'تفعيل نظام الاعلانات',
                ),
                array(
                    'type'      => 'text',
                    'name'      => 'adsensepub',
                    'title'     => 'معرف ادسنس',
                ),
            ),
            'seoplus-ads-group',
            'sp_theme_ads',
            'seoplus_settings_ads'
        );

        
    # theme author ads
    add_settings_section(
        'sp_author_ads',
        'مشاركة الارباح',
        'sp_settings_option',
        'seoplus_author_ads',
        array(
            'before_section' => '<div class="settings_group active" id="sp_author_ads">',
            'after_section' => '</div>',
        )
    );

        # theme author ads
        setting_fields(
            'sp_author_ads',
            array(
                array(
                    'type'      => 'switch',
                    'name'      => 'author_ads_active',
                    'title'     => 'تفعيل نظام مشاركة الارباح',
                ),
                array(
                    'type'      => 'text',
                    'name'      => 'author_ratio',
                    'title'     => 'نسبه ظهور الاعلان الافتراضية',
                ),
            ),
            'seoplus-author-ads-group',
            'sp_author_ads',
            'seoplus_author_ads'
        );

}

function sp_custom_setting(){

    # theme Min Settings 
    add_settings_section(
        'sp_minSettings',
        'الاعدادات الاساسيه',
        'sp_settings_option',
        'seoplus_main_settings',
        array(
            'before_section' => '<div class="settings_group active" id="sp_minSettings">',
            'after_section' => '</div>',
        )
    );

    # theme Min fields
    setting_fields(
        'sp_minSettings',
        array(
            array(
                'type'      => 'switch',
                'name'      => 'postTime',
                'title'     => 'وقت نشر المقال [آخر تحديث]',
            ),
            array(
                'type'      => 'switch',
                'name'      => 'themeStyle',
                'title'     => 'تغيير طريقة العرض',
            ),
            array(
                'type'      => 'switch',
                'name'      => 'rmpostscat',
                'title'     => 'حذف القسم من على صور المقالات',
            ),

            array(
                'type'      => 'radio',
                'name'      => 'QuickAccessMenu',
                'title'     => 'تغيير شكل اداة [قائمة الوصول السريع]',
                'SubArray'  => array(
                    array(
                        'value'    => 'one',
                        'image'    => get_template_directory_uri() . '/admin/template/buttons/1.png',
                        'text'     => 'الشكل الاول',
                    ),
                    array(
                        'value'    => 'tow',
                        'image'    => get_template_directory_uri() . '/admin/template/buttons/2.png',
                        'text'     => 'الشكل الثاني',
                    ),
                    array(
                        'value'    => 'tree',
                        'image'    => get_template_directory_uri() . '/admin/template/buttons/3.png',
                        'text'     => 'الشكل الثالث',
                    ),
                    array(
                        'value'    => 'four',
                        'image'    => get_template_directory_uri() . '/admin/template/buttons/4.png',
                        'text'     => 'الشكل الرابع',
                    ),
                    array(
                        'value'    => 'five',
                        'image'    => get_template_directory_uri() . '/admin/template/buttons/5.png',
                        'text'     => 'اخفاء الشكل',
                    ),
                ),
            ),


            array(
                'type'      => 'switch',
                'name'      => 'darkmain',
                'title'     => 'تفعيل الدارك مود كلون اساسي',
            ),

            array(
                'type'      => 'switch',
                'name'      => 'disableDark',
                'title'     => 'اخفاء زر الدارك مود',
            ),
            array(
                'type'      => 'switch',
                'name'      => 'changeDark',
                'title'     => 'تغيير لون الدارك مود',
            ),

            array(
                'type'      => 'switch',
                'name'      => 'coverImg',
                'title'     => 'تفعيل اداة تجاوب الصور المصغرة',
            ),
            array(
                'type'      => 'switch',
                'name'      => 'stopCopying',
                'title'     => 'تفعيل اداة منع نسخ النصوص',
            ),
            array(
                'type'      => 'range',
                'name'      => 'siteWidth',
                'title'     => 'عرض الموقع',
                'min'       =>  '992',
                'max'       =>  '1300',
            ),
            array(
                'type'      => 'range',
                'name'      => 'sidebarWidth',
                'title'     => 'عرض السايد بار',
                'min'       =>  '250',
                'max'       =>  '480',
            ),
        ),
        'sp-settings-group-main',
        'sp_minSettings',
        'seoplus_main_settings'
    );

    # Header settings
    add_settings_section(
        'sp_header',
        'إعدادات القائمه العلوية',
        'sp_settings_option',
        'seoplus_header_settings',
        array(
            'before_section' => '<div class="settings_group" id="sp_header">',
            'after_section' => '</div>',
        )
    );
    
    # Header fields
    setting_fields(
        'sp_header',
        array(
            array(
                'type'      => 'image',
                'name'      => 'logoUrl',
                'title'     => 'شعار المدونه',
            ),
            array(
                'type'      => 'radio',
                'name'      => 'HeaderStyle',
                'title'     => 'شكل القائمه العلوية',
                'SubArray'  => array(
                    array(
                        'value'    => 'one',
                        'image'    => get_template_directory_uri() . '/admin/template/header-images/1.png',
                        'text'     => 'الشكل الاول',
                    ),
                    array(
                        'value'    => 'tow',
                        'image'    => get_template_directory_uri() . '/admin/template/header-images/2.png',
                        'text'     => 'الشكل الثاني',
                    ),
                    array(
                        'value'    => 'tree',
                        'image'    => get_template_directory_uri() . '/admin/template/header-images/3.png',
                        'text'     => 'الشكل الثالث',
                    ),
                    array(
                        'value'    => 'four',
                        'image'    => get_template_directory_uri() . '/admin/template/header-images/4.png',
                        'text'     => 'الشكل الرابع',
                    ),
                ),
            ),
            array(
                'type'      => 'switch',
                'name'      => 'stickyHeader',
                'title'     => 'تثبيت القائمه العلوية',
            ),
            array(
                'type'      => 'range',
                'name'      => 'linkFontSize',
                'title'     => 'حجم خط الروابط',
                'min'       =>  '13',
                'max'       =>  '18',
            ),
            array(
                'type'      => 'color',
                'name'      => 'headerBg',
                'title'     => 'خلفية القائمة العلوية',
            ),
            array(
                'type'      => 'color',
                'name'      => 'linkColor',
                'title'     => 'لون الروابط',
            ),
            array(
                'type'      => 'color',
                'name'      => 'SearchButtonBg',
                'title'     => 'خلفيه زر البحث',
            ),
            array(
                'type'      => 'color',
                'name'      => 'SearchButtonIc',
                'title'     => 'ايقونة زر البحث',
            ),
            array(
                'type'      => 'switch',
                'name'      => 'SearchButton',
                'title'     => 'تفعيل زر البحث',
            ),
        ),
        'sp-settings-group-header',
        'sp_header',
        'seoplus_header_settings'
    );

    # theme Min Colors
    add_settings_section(
        'sp_minColor',
        'تخصيص الالوان',
        'sp_settings_option',
        'seoplus_minColor_settings',
        array(
            'before_section' => '<div class="settings_group" id="sp_minColor">',
            'after_section' => '</div>',
        )
    );

    # theme Colors fields
    setting_fields(
        'sp_minColor',
        array(
            array(
                'type'      => 'color',
                'name'      => 'bodyBg',
                'title'     => 'لون خلفيه المدونه',
            ),
            array(
                'type'      => 'color',
                'name'      => 'keyColor',
                'title'     => 'اللون الاساسي',
            ),
            array(
                'type'      => 'color',
                'name'      => 'stepColor',
                'title'     => 'اللون المساعد',
            ),
            array(
                'type'      => 'color',
                'name'      => 'gradColor',
                'title'     => 'لون خلفيه الويدجات',
            ),
            array(
                'type'      => 'color',
                'name'      => 'textColor',
                'title'     => 'لون النصوص',
            ),
        ),
        'sp-settings-group-minColor',
        'sp_minColor',
        'seoplus_minColor_settings'
    );

    # theme Aside Section
    add_settings_section(
        'sp_aside',
        'ألقائمه الجانبيه',
        'sp_settings_option',
        'seoplus_aside_settings',
        array(
            'before_section' => '<div class="settings_group" id="sp_aside">',
            'after_section' => '</div>',
        )
    );

    # theme Aside fields
    setting_fields(
        'sp_aside',
        array(
            array(
                'type'      => 'switch',
                'name'      => 'home',
                'title'     => 'تفعيل اداة [اخفاء القائمة الجانبية من الرئيسية]',
            ),
            array(
                'type'      => 'switch',
                'name'      => 'post',
                'title'     => 'تفعيل اداة [اخفاء القائمة الجانبية من المقال]',
            ),
            array(
                'type'      => 'switch',
                'name'      => 'page',
                'title'     => 'تفعيل اداة [اخفاء القائمة الجانبية من الصفحات]',
            ),
            array(
                'type'      => 'switch',
                'name'      => 'mobile',
                'title'     => 'تفعيل اداة [اخفاء القائمة الجانبية من الهاتف]',
            ),
        ),
        'sp-settings-group-aside',
        'sp_aside',
        'seoplus_aside_settings'
    );

    # theme LastPosts
    add_settings_section(
        'sp_lastPosts',
        'اعدادات اخر المشاركات',
        'sp_settings_option',
        'seoplus_last_posts_settings',
        array(
            'before_section' => '<div class="settings_group" id="sp_lastPosts">',
            'after_section' => '</div>',
        )
    );

    # theme LastPosts
    setting_fields(
        'sp_lastPosts',
        array(
            array(
                'type'      => 'switch',
                'name'      => 'disaple',
                'title'     => 'اخفاء اداة [اخر المشاركات]',
            ),
            array(
                'type'      => 'radio',
                'name'      => 'style',
                'title'     => 'تغيير شكل اداة [أخر المشاركات]',
                'SubArray'  => array(
                    array(
                        'value'    => 'Sp-postsnew0',
                        'image'    => 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi9rlAEN-0FSvojauKrBokx7xb3j1xoCRDvdlu9UQ1DxrYzGDTehnyGttEin6kUM3YgXQQd7gv4DZ87qqaKSoL5CmjGeYT85_SOxnvuOQhJUbBtFAc8F5U2Dhcncbjjb5j-4Jkla6DDIvttqVIReNXKvFy-KlsyIsnPsiOjbg-4ZEQGLgaw6n4Hm772/s1600-rw/postnew0.png',
                        'text'     => 'الشكل الاول',
                    ),
                    array(
                        'value'    => 'Sp-postsnew0  noImg',
                        'image'    => 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi9rlAEN-0FSvojauKrBokx7xb3j1xoCRDvdlu9UQ1DxrYzGDTehnyGttEin6kUM3YgXQQd7gv4DZ87qqaKSoL5CmjGeYT85_SOxnvuOQhJUbBtFAc8F5U2Dhcncbjjb5j-4Jkla6DDIvttqVIReNXKvFy-KlsyIsnPsiOjbg-4ZEQGLgaw6n4Hm772/s1600-rw/postnew0.png',
                        'text'     => 'الشكل الثاني',
                    ),
                    array(
                        'value'    => 'Sp-postsnew',
                        'image'    => 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg0pDXa5aXUT2GkB3jXmDOz5nr4wHY4hQFXDHar6ZCLvS-KTwpWeA6eyXGKad2G8a1nsboBYbpjsHeF7ycoTPxa3xLraXTrtBzA5xVG4vz5DM2s79-Uu4nkHlAI8lv8elTe6h1AOU3cs0AqN192yeL0q9l8CY-g5t9qkpEeIrLYLOzQeO6RHQ76mOrH/s1600-rw/postnew1.png',
                        'text'     => 'الشكل الثالث',
                    ),
                    array(
                        'value'    => 'Sp-posts1',
                        'image'    => 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgWwthj87DJjjvGlOb5cWfyHTig1oL1WHAtO4qFqxlTVYYqBb3tIcA-AKpViSR_fPYSxENmpSMe9RxYdiNRw5Mbhti3zXjhdzE4H_DswJ6c3N8SAe_N4UHcVkeg6NhFWQYR6igqhyLetDXroQvkS55b8r_yTSe7Nmmhz-hP2-u1bLw4dLSRc6Ufnrbm/s1600-rw/post1.png',
                        'text'     => 'الشكل الرابع',
                    ),

                    array(
                        'value'    => 'Sp-posts7',
                        'image'    => 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiETqbPr9nyytNG19pX_fZLc9L-QgyAi19Wcv4Lo7U5x7l5KXraE0RTRFhXTXJfObjd2UeIKRm601oWSw-iZtPdgMlxOyiG30DhrsdXOn0NTWUu4badL3dOWRsqqjVLtrEult0AvmMgQ9LomIcR3egYgu2bFkumG8s1-ssDRqKJBj4sOgu7QcF7wzJl/s1600-rw/post7.png',
                        'text'     => 'الشكل السادس',
                    ),
                ),
            ),
            array(
                'type'      => 'radio',
                'name'      => 'loadMore',
                'title'     => 'تغيير شكل اداة [عرض المزيد (التي تظهر اسفل اخر المشاركات)]',
                'SubArray'  => array(
                    array(
                        'value'    => 'one',
                        'image'    => get_template_directory_uri() . '/admin/template/buttons/zr1.png',
                        'text'     => 'الشكل الاول',
                    ),
                    array(
                        'value'    => 'tow',
                        'image'    => get_template_directory_uri() . '/admin/template/buttons/zr2.png',
                        'text'     => 'الشكل الثاني',
                    ),
                ),
            ),
        ),
        'sp-settings-group-lastposts',
        'sp_lastPosts',
        'seoplus_last_posts_settings'
    );

    # theme Post customization Section
    add_settings_section(
        'sp_postCustom',
        'تخصيص المقالات والصفحات',
        'sp_settings_option',
        'seoplus_postCustom_settings',
        array(
            'before_section' => '<div class="settings_group" id="sp_postCustom">',
            'after_section' => '</div>',
        )
    );

    # theme Post customization fields
    setting_fields(
        'sp_postCustom',
        array(
            array(
                'type'      => 'color',
                'name'      => 'titleColor',
                'title'     => 'لون نص عنوان المقالات والصفحات',
            ),
            array(
                'type'      => 'range',
                'name'      => 'titleSize',
                'title'     => 'حجم نص عنوان المقالات والصفحات',
                'min'       =>  '18',
                'max'       =>  '40',
            ),
            array(
                'type'      => 'color',
                'name'      => 'contentColor',
                'title'     => 'لون نص محتوي المقالات والصفحات',
            ),
            array(
                'type'      => 'range',
                'name'      => 'contentSize',
                'title'     => 'حجم نص محتوي المقالات والصفحات',
                'min'       =>  '13',
                'max'       =>  '30',
            ),
            array(
                'type'      => 'color',
                'name'      => 'contentURLColor',
                'title'     => 'لون نص الروابط في المقالات والصفحات',
            ),
        ),
        'sp-settings-group-postcustom',
        'sp_postCustom',
        'seoplus_postCustom_settings'
    );

    # theme Post Features Section
    add_settings_section(
        'sp_postFeatures',
        'مميزات اضافية للمقال',
        'sp_settings_option',
        'seoplus_postFeatures_settings',
        array(
            'before_section' => '<div class="settings_group" id="sp_postFeatures">',
            'after_section' => '</div>',
        )
    );

    # theme Post Features fields
    setting_fields(
        'sp_postFeatures',
        array(
            array(
                'type'      => 'switch',
                'name'      => 'postRandomActive',
                'title'     => 'تفعيل اداة [قد يعجبك ايضا]',
            ),
            array(
                'type'      => 'switch',
                'name'      => 'postRandomIsRand',
                'title'     => 'مقالات عشوائية [قد يعجبك ايضا]',
            ),
            array(
                'type'      => 'radio',
                'name'      => 'postRandom',
                'title'     => 'تغيير شكل اداة [قد يعجبك ايضا]',
                'SubArray'  => array(
                    array(
                        'value'    => 'Sp-posts6',
                        'image'    => 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhN4esgn_U3ZYdst1ppo8lkRHc4lARQ7CLbGlCV3L2jyxT21yXwQdkGdqDE86E9NJTF7VZW_jthCBrDox9AMuCGWglRQ42Afop9UB1YyDYgHl0Ky4nsoxtYilYD4VE2KJLM9lQRJqmgn4JyJytUVA5S7NqnID0AZbeJxgEGIE3UDM_2-9v-47EwRzwQ/s1600-rw/post6.png',
                        'text'     => 'الشكل الاول',
                    ),
                    array(
                        'value'    => 'Sp-posts3',
                        'image'    => 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjEkBZFZxQe1i8YTRJNgUsLXkY1vpJL404TDauhgDrGjDJ5MPlcUxG51MEgW63Bcan1aPi0Yxd8AXNW_blqK4G0BRD99sK-eRSGqa66A2LOVC_f-eY8YmGuTFkw03XE46NCOPLdPjGbkNlTTqJj_UcNkvDOpbLUgYVAp7hRvQqbBZEwFqafutEh_PKM/s1600-rw/post3.png',
                        'text'     => 'الشكل الثاني',
                    ),
                    array(
                        'value'    => 'Sp-posts1',
                        'image'    => 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgWwthj87DJjjvGlOb5cWfyHTig1oL1WHAtO4qFqxlTVYYqBb3tIcA-AKpViSR_fPYSxENmpSMe9RxYdiNRw5Mbhti3zXjhdzE4H_DswJ6c3N8SAe_N4UHcVkeg6NhFWQYR6igqhyLetDXroQvkS55b8r_yTSe7Nmmhz-hP2-u1bLw4dLSRc6Ufnrbm/s1600-rw/post1.png',
                        'text'     => 'الشكل الثالث',
                    ),
                ),
            ),
            array( 
                'type'      => 'number',
                'min'       =>  '1',
                'max'       =>  '20',
                'name'      => 'postRandomNumper',
                'title'     => 'عدد مقالات اداة [قد يعجبك ايضا]',
            ),

            array(
                'type'      => 'switch',
                'name'      => 'retPostsActive',
                'title'     => 'تفعيل اداة [مقالات قد تهمك]',
            ),
            array(
                'type'      => 'switch',
                'name'      => 'retPostsIsRand',
                'title'     => 'مقالات عشوائية [مقالات قد تهمك]',
            ),
            array( 
                'type'      => 'number',
                'min'       =>  '1',
                'max'       =>  '20',
                'name'      => 'retPostsNumper',
                'title'     => 'عدد مقالات اداة [مقالات قد تهمك]',
            ),
            array(
                'type'      => 'radio',
                'name'      => 'retPosts',
                'title'     => 'تغيير شكل اداة [مقالات قد تهمك]',
                'SubArray'  => array(
                    array(
                        'value'    => 'Sp-posts1',
                        'image'    => 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgWwthj87DJjjvGlOb5cWfyHTig1oL1WHAtO4qFqxlTVYYqBb3tIcA-AKpViSR_fPYSxENmpSMe9RxYdiNRw5Mbhti3zXjhdzE4H_DswJ6c3N8SAe_N4UHcVkeg6NhFWQYR6igqhyLetDXroQvkS55b8r_yTSe7Nmmhz-hP2-u1bLw4dLSRc6Ufnrbm/s1600-rw/post1.png',
                        'text'     => 'الشكل الاول',
                    ),
                    array(
                        'value'    => 'Sp-posts7',
                        'image'    => 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiETqbPr9nyytNG19pX_fZLc9L-QgyAi19Wcv4Lo7U5x7l5KXraE0RTRFhXTXJfObjd2UeIKRm601oWSw-iZtPdgMlxOyiG30DhrsdXOn0NTWUu4badL3dOWRsqqjVLtrEult0AvmMgQ9LomIcR3egYgu2bFkumG8s1-ssDRqKJBj4sOgu7QcF7wzJl/s1600-rw/post7.png',
                        'text'     => 'الشكل الثالث',
                    ),
                    array(
                        'value'    => 'Sp-posts6',
                        'image'    => 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhN4esgn_U3ZYdst1ppo8lkRHc4lARQ7CLbGlCV3L2jyxT21yXwQdkGdqDE86E9NJTF7VZW_jthCBrDox9AMuCGWglRQ42Afop9UB1YyDYgHl0Ky4nsoxtYilYD4VE2KJLM9lQRJqmgn4JyJytUVA5S7NqnID0AZbeJxgEGIE3UDM_2-9v-47EwRzwQ/s1600-rw/post6.png',
                        'text'     => 'الشكل الرابع',
                    ),
                ),
            ),

            array(
                'type'      => 'switch',
                'name'      => 'removeAuthor',
                'title'     => 'اخفاء اداة كاتب الموضوع',
            ),
        ),
        'sp-settings-group-postfeatures',
        'sp_postFeatures',
        'seoplus_postFeatures_settings'
    );


    # Redirect settings
    add_settings_section(
        'sp_redirect',
        'اعدادات صفحة اعادة التوجيه',
        'sp_settings_option',
        'seoplus_redirect_settings',
        array(
            'before_section' => '<div class="settings_group" id="sp_redirect">',
            'after_section' => '</div>',
        )
    );
    # Redirect fields
    setting_fields( 
        'sp_redirect',
        array(
            array(
                'type'      => 'switch',
                'name'      => 'isActicve',
                'title'     => 'تفعيل اعادة التوجية',
            ),

            array(
                'type'      => 'select_pages',
                'name'      => 'isPageId',
                'title'     => 'رابط الصفحة',
            ),
            array(
                'type'      => 'range',
                'name'      => 'isTimer',
                'title'     => 'وقت عداد صفحة الأنتظار',
                'min'       =>  '6',
                'max'       =>  '30',
            ),
            array(
                'type'      => 'switch',
                'name'      => 'isProtection',
                'title'     => 'وضع حماية الرابط',
            ),
            array(
                'type'      => 'switch',
                'name'      => 'isPopup',
                'title'     => 'تحويل الروابط داخل صفحة المقال',
            ),
            array(
                'type'      => 'switch',
                'name'      => 'isSkin',
                'title'     => 'تطبيق تنسيق زر التحميل علي أي رابط خارجي',
            ),
            array(
                'type'      => 'radio',
                'name'      => 'skinStyle',
                'title'     => 'شكل الزر',
                'SubArray'  => array(
                    array(
                        'value'    => 'one',
                        'image'    => '#1',
                        'text'    => 'شكل الزر الاول',
                    ),
                    array(
                        'value'    => 'tow',
                        'image'    => '#2',
                        'text'    => 'شكل الزر الثاني',
                    ),
                ),
            ),
            array(
                'type'      => 'switch',
                'name'      => 'autoRedirect',
                'title'     => 'تفعيل ميزة التوجيه التلقائي',
            ),
            array(
                'type'      => 'textarea',
                'name'      => 'blockList',
                'title'     => 'الروابط المستثناه من إعادة التحويل',
            ),
            array(
                'type'      => 'text',
                'name'      => 'textConfigure',
                'title'     => 'النص الذي يظهر عند الإنتظار',
            ),
            array(
                'type'      => 'text',
                'name'      => 'textReady',
                'title'     => 'نص رابط التوجيه',
            ),
            array(
                'type'      => 'text',
                'name'      => 'textError',
                'title'     => 'نص ان كان الرابط خطاء',
            ),
        ),
        'sp-settings-group-redirect',
        'sp_redirect',
        'seoplus_redirect_settings'
    );

}



function sp_settings_option(){
    // echo 'Custom Info';
}



function sp_sanitize_text($input){
    $output = sanitize_text_field($input);
    $output = str_replace('@', '', $input);
    return $output;
}


function seoplus_users_mangment(){
    require_once( get_template_directory() . '/admin/template/usersmangment/mainsettings.php');
}
function seoplus_users_mangment_white_list(){
    require_once( get_template_directory() . '/admin/template/usersmangment/settings-white-list.php');
}

function seoplus_settings_ads(){
    require_once( get_template_directory() . '/admin/template/seoplus_ads/settings-ads.php');
}
function seoplus_author_ads(){
    require_once( get_template_directory() . '/admin/template/seoplus_ads/settings-author-ads.php');
}

function seoplus_ads_text(){
    require_once( get_template_directory() . '/admin/template/seoplus_ads/settings-ads-txt.php');
}

function seoplus_settings_page(){
    require_once( get_template_directory() . '/admin/template/settings_main/settings-main.php');
}
function seoplus_main_settings(){
    require_once( get_template_directory() . '/admin/template/settings_main/settings-main-setting.php');
}
function seoplus_header_settings(){
    require_once( get_template_directory() . '/admin/template/settings_main/settings-header-setting.php');
}
function seoplus_aside_settings(){
    require_once( get_template_directory() . '/admin/template/settings_main/settings-aside-setting.php');
}
function seoplus_last_posts_settings(){
    require_once( get_template_directory() . '/admin/template/settings_main/settings-last-posts-setting.php');
}
function seoplus_redirect_settings(){
    require_once( get_template_directory() . '/admin/template/settings_main/settings-redirect-setting.php');
}
function seoplus_postFeatures_settings(){
    require_once( get_template_directory() . '/admin/template/settings_main/settings-postFeatures-setting.php');
}
function seoplus_postCustom_settings(){
    require_once( get_template_directory() . '/admin/template/settings_main/settings-postCustom-setting.php');
}
function seoplus_minColor_settings(){
    require_once( get_template_directory() . '/admin/template/settings_main/settings-minColor-setting.php');
}
