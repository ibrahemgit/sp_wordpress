<div class="wrap">

<?php settings_errors(); ?>

<form method="post" action="options.php">

<?php

//   delete_option('sp_author_ads');

echo "<pre>";
print_r(getoptions('sp_author_ads'));
echo "</pre>";
?>
    <?php settings_fields( 'seoplus-author-ads-group' ); ?>

    <div class='settings_box'>
        <div class='settings_sections'>
            <h1>اعدادات القالب</h1>
            <div class='prim_title'>
            </div>
            <?php submit_button( ); ?>

            <?php do_settings_sections( 'seoplus_author_ads' ); ?>
            
        <?php 

    // إعداد الاستعلام لجلب جميع المستخدمين
    addnewusersloob(array(
        'orderby' => 'display_name',
        'order'   => 'ASC',
        'role__in' => [ 'administrator' ]
    ),"المديرين" , true);

    addnewusersloob(array(
        'orderby' => 'display_name',
        'order'   => 'ASC',
        'role__in' => [ 'editor' ]
    ),"المحريين" , true);

    addnewusersloob(array(
        'orderby' => 'display_name',
        'order'   => 'ASC',
        'role__in' => [ 'author' ]
    ),"الكتاب" , true);

    addnewusersloob(array(
        'orderby' => 'display_name',
        'order'   => 'ASC',
        'role__in' => [ 'contributor' ]
    ),"المساهمين" , false);



    function addnewusersloob( $args , $roletitle , $def ){
        // جلب المستخدمين بناءً على الإعدادات
        $users = get_users($args);

        // عرض قائمة المستخدمين
        if (!empty($users)) {
            echo '<div class="users_section">';

            echo "<div class='prim_title'><h2> ". $roletitle ." </h2></div>";
            echo '<div class="users-list">';
            $usersads = getoptions('sp_author_ads');
            $usersarray = $usersads['users'];
            foreach ($users as $user) {
                $user_id = $user->ID;
                $user_name = $user->display_name;
                $user_url = get_edit_user_link($user_id);
                $user_roles = $user->roles; // جلب الأدوار


                if($def){
                    $useractive = isset($usersarray[$user_id]['useractive']) ? $usersarray[$user_id]['useractive'] : '1';
                }else{
                    $useractive = isset($usersarray[$user_id]['useractive']) ? $usersarray[$user_id]['useractive'] : '0';
                }
                
                $userratio = isset($usersarray[$user_id]['custom_ratio']) ? $usersarray[$user_id]['custom_ratio'] : $usersads['author_ratio'];

                $roles_names = array_map(function($role) {
                    return translate_user_role($role);
                }, $user_roles);
                $roles_string = implode(', ', $roles_names);

                $custom_ratio = isset($usersarray[$user_id]['custom_ratio']) ? "<input class='regular-text' type='number' name='sp_author_ads[users][$user_id][custom_ratio]' value='".$userratio."' step='1' min='0' max='100'>" : "<span id='generate-button'>نسبة مخصصه</span>";

                // echo isset($usersarray[$user_id]['custom_ratio']);
                echo "  
                <div class='user' data-rol='".esc_html($roles_string)."' data-id='".$user_id."'>
                    <label class='switch'>
                        <input type='hidden' class='hide' name='sp_author_ads[users][$user_id][useractive]' value='".$useractive."'>
                        <input type='checkbox' " . checked($useractive, '1', false) . ">
                        <span class='slider round'></span>
                    </label>
                    ". get_avatar( get_the_author_meta('ID') ) ."
                    <div class='user_info_ratio'>
                        <a href='" . esc_url($user_url) . "'>".esc_html($user_name)."</a>
                        ".$custom_ratio ."
                    </div>
                </div>
                ";

            }
            echo '</div></div>';
        } else {
            echo "<div class='users_section'> <div class='prim_title'><h2> ". $roletitle ." </h2></div>
            <p class='description'>لا يوجد مستخدمين في هذة الرتبه . </p>
            </div>";
        }

    }

        ?>
<!-- <input class='regular-text' type='number' name='sp_author_ads[users][$user_id][ratio]' value='".$userratio."' step='1' min='0' max='100'> -->

        <script>
jQuery(document).ready(function($) {
    $('.user').each(function() {
        let author_ratio = $('.author_ratio input').val();
        let user_id = $(this).data('id');
        $(this).find('#generate-button').on('click', function() {
            var ratio = $('<input>', {
                class: 'regular-text',
                type: 'number',
                name: "sp_author_ads[users][" + user_id + "][custom_ratio]",
                value: author_ratio,
                step: "1",
                min: "0",
                max: "100"
            });
            $(this).parent().append(ratio);
            $(this).remove();
        });
    });
});




        </script>
        </div>

    </div>

</form>

</div>