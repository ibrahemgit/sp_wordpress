<div class="wrap">

<?php settings_errors(); ?>

<form method="post" action="options.php">

    <?php settings_fields( 'seoplus-ads-text-group' ); ?>

    <div class='settings_box'>
        <div class='settings_sections'>
            <h1>اعدادات القالب</h1>
            <div class='prim_title'>
            </div>
            <?php submit_button( ); ?>

            <?php do_settings_sections( 'seoplus_settings_ads_text' ); ?>
            
        </div>

    </div>
<?php

?>
</form>

</div>