<div class="wrap">

<?php settings_errors(); ?>

<?php 

// delete_option('sp_theme_ads');



 ?>
<form method="post" action="options.php">

    <?php settings_fields( 'seoplus-ads-group' ); ?>

    <div class='settings_box'>

        <div class='settings_sections'>
            <div class='prim_title'>
                <h1>اعدادات ألاعلانات</h1>
                <?php submit_button( ); ?>
            </div>
            <?php do_settings_sections( 'seoplus_settings_ads' ); ?>
            
            <div id="fields-container">
            <?php
$kv = array(
    'mainads' => 'اعلاانات اساسية',
    'pads' => 'اعلاانات الفقرات',
    'adsense' => 'اعلان متجاوب',
    'customecode' => 'كود يدوي',
    'ad_top' => 'اعلان اول المقال',
    'ad_cent' => 'اعلان منتصف المقال',
    'ad_bot' => 'اعلان اخر المقال',
    'ad_p1' => 'اعلان اول فقرة',
    'ad_p2' => 'اعلان ثاني فقرة',
    'ad_p3' => 'اعلان ثالث فقرة',
    'ad_p4' => 'اعلان رابع فقرة',
    'ad_p5' => 'اعلان خامس فقرة',
    'ad_p6' => 'اعلان سادس فقرة',
    'ad_p7' => 'اعلان سابع فقرة',
);

$themeads = getoptions('sp_theme_ads', "userAds");

function create_option($value, $label, $selected_value) {
    return "<option value='$value' " . selected($value, $selected_value, false) . ">$label</option>";
}

function create_select($name, $options, $selected_value, $classes = '') {
    $html = "<select class='$classes' name='$name'>";
    foreach ($options as $value => $label) {
        $html .= create_option($value, $label, $selected_value);
    }
    $html .= "</select>";
    return $html;
}

function create_optgroup($label, $options, $selected_value) {
    $html = "<optgroup label='$label'>";
    foreach ($options as $value => $label) {
        $html .= create_option($value, $label, $selected_value);
    }
    $html .= "</optgroup>";
    return $html;
}

foreach ($themeads as $ads) {
    $adtype = $ads['adtype'];
    $adlocation = $ads['adlocation'];
    $adcode = $ads['adcode'];
    $adActive = $ads['adActive'];
    $title = $kv[$adtype] . " - " . $kv[$adlocation];
    $aryaHide = $adtype == 'customecode' ? '' : 'hide';
    $selectHide = $adtype == 'adsense' ? '' : 'hide';

    echo "
        <div class='adbox'>
            <div class='adtitle'>
                <label class='switch'>
                    <input type='hidden' class='hide' name='sp_theme_ads[userAds][$adlocation][adActive]' value='$adActive'>
                    <input type='checkbox' " . checked($adActive, '1', false) . ">
                    <span class='slider round'></span>
                </label>
                <span class='titleText'>$title</span>
                <span class='deleteAd'></span>
            </div>
            " . create_select("sp_theme_ads[userAds][$adlocation][adtype]", array('adsense' => $kv['adsense'], 'customecode' => $kv['customecode']), $adtype, 'added adtype') . "
            <select class='added adlocation' name='sp_theme_ads[userAds][$adlocation][adlocation]'>
                " . create_optgroup($kv['mainads'], array('ad_top' => $kv['ad_top'], 'ad_cent' => $kv['ad_cent'], 'ad_bot' => $kv['ad_bot']), $adlocation) . "
                " . create_optgroup($kv['pads'], array(
                    'ad_p1' => $kv['ad_p1'],
                    'ad_p2' => $kv['ad_p2'],
                    'ad_p3' => $kv['ad_p3'],
                    'ad_p4' => $kv['ad_p4'],
                    'ad_p5' => $kv['ad_p5'],
                    'ad_p6' => $kv['ad_p6'],
                    'ad_p7' => $kv['ad_p7']
                ), $adlocation) . "
            </select>
            <textarea placeholder='أضف الكود هنا' class='adcode $aryaHide' name='sp_theme_ads[userAds][$adlocation][adcode]'>$adcode</textarea>
        </div>
    ";
}
?>

            </div>

            <span id="generate-button">Generate Fields</span>

            <script>

jQuery(document).ready(function($) {
    var kv = {
        'adsense': 'اعلان متجاوب',
        'customecode': 'كود يدوي',
        'ad_top' : 'اعلان اول المقال',
        'ad_cent' : 'اعلان منتصف المقال',
        'ad_bot' : 'اعلان اخر المقال',
        'ad_p1' : 'اعلان اول فقرة',
        'ad_p2' : 'اعلان ثاني فقرة',
        'ad_p3' : 'اعلان ثالث فقرة',
        'ad_p4' : 'اعلان رابع فقرة',
        'ad_p5' : 'اعلان خامس فقرة',
        'ad_p6' : 'اعلان سادس فقرة',
        'ad_p7' : 'اعلان سابع فقرة',
    };

    function updateAdTitle($element) {
        var adloc = $element.find('.adlocation').val();
        var adtyp = $element.find('.adtype').val();
        var associatedTitle = $element.find('.adtitle .titleText');
        var getText = kv[adtyp] + " - " + kv[adloc];
        associatedTitle.text(getText);
    }

    function toggleAdTypeFields($element) {
        var selected = $element.find('.adtype').val();
        if (selected === 'adsense') {
            $element.find('select.adsize').show();
            $element.find('textarea.adcode.hide').hide();
        } else {
            $element.find('select.adsize').hide();
            $element.find('textarea.adcode.hide').show();
        }
    }

    function updateAdLocationNames($element) {
        var selectedOption = $element.find('.adlocation').val();
        $element.find('.adtitle label.switch input.hide').attr('name', `sp_theme_ads[userAds][${selectedOption}][adActive]`);
        $element.find('textarea.adcode').attr('name', `sp_theme_ads[userAds][${selectedOption}][adcode]`);
        $element.find('select.adsize').attr('name', `sp_theme_ads[userAds][${selectedOption}][adsize]`);
        $element.find('select.adtype').attr('name', `sp_theme_ads[userAds][${selectedOption}][adtype]`);
        $element.find('select.adlocation').attr('name', `sp_theme_ads[userAds][${selectedOption}][adlocation]`);
    }

    $('#generate-button').click(generateFields);

    $(document).on('change', '.adbox select.added', function() {
        updateAdTitle($(this).parent());
    });

    $(document).on('change', '.adbox select.adtype', function() {
        toggleAdTypeFields($(this).parent());
    });

    $(document).on('change', '.adbox select.adlocation', function() {
        updateAdLocationNames($(this).parent());
    });

    $(document).on('click', 'span.deleteAd', function() {
        $(this).closest('.adbox').remove();
    });

    function generateFields() {
        var adTitleText = kv['adsense'] + ' - ' + kv['ad_top'];
        
        var title = $('<div>', { class: 'adtitle' }).append(
            $('<label>', { class: 'switch' }).append(
                $('<input>', { type: 'hidden', class: 'hide', name: 'sp_theme_ads[userAds][ad_top][adActive]', value: '1' }),
                $('<input>', { type: 'checkbox', checked: true }),
                $('<span>', { class: 'slider round' })
            ),
            $('<span>', { class: 'titleText', text: adTitleText }),
            $('<span>', { class: 'deleteAd' })
        );

        var adtype = $('<select>', { class: 'added adtype', name: 'sp_theme_ads[userAds][ad_top][adtype]' }).append(
            $('<option>', { value: 'adsense', text: kv['adsense'] }),
            $('<option>', { value: 'customecode', text: kv['customecode'] })
        );

        var adlocation = $('<select>', { class: 'added adlocation', name: 'sp_theme_ads[userAds][ad_top][adlocation]' }).append(
            $('<optgroup>', { label: 'اعلانات اساسيه' }).append(
                $('<option>', { value: 'ad_top', text: kv['ad_top'] }),
                $('<option>', { value: 'ad_cent', text: kv['ad_cent'] }),
                $('<option>', { value: 'ad_bot', text: kv['ad_bot'] })
            ),
            $('<optgroup>', { label: 'اعلانات الفقرات' }).append(
                $.map(kv, function(text, value) {
                    if (value.startsWith('ad_p')) {
                        return $('<option>', { value: value, text: text });
                    }
                })
            )
        );

        // var adsize = $('<select>', { class: 'adsize', name: 'sp_theme_ads[userAds][ad_top][adsize]' }).append(
        //     $('<option>', { value: 'auto', text: 'متجاوب' })
        // );

        var adcode = $('<textarea>', { class: 'adcode hide', name: 'sp_theme_ads[userAds][ad_top][adcode]', placeholder: 'أضف الكود هنا' });

        var container = $('<div>', { class: 'adbox' }).append(title, adtype, adlocation, /* adsize,*/ adcode);

        $('#fields-container').append(container);
    }
});

        </script>

        </div>
    </div>

</form>

</div>