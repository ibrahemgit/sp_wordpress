<div class="wrap">

<?php settings_errors(); 

// delete_option('sp_users_mangment');

?>

<form method="post" action="options.php">

    <?php settings_fields( 'seoplus-users-mangment-group' ); ?>

    <div class='settings_box'>
        <div class='settings_sections'>
            <h1>اعدادات القالب</h1>
            <div class='prim_title'>
            </div>
            <?php submit_button( ); ?>

            <?php do_settings_sections( 'seoplus_users_mangment' ); ?>
            

            <div class='h'>

            <h1>استثناء اعضاء من نظام التحقق</h1>
            </div>
            <?php 

// إعداد الاستعلام لجلب جميع المستخدمين
addnewusersloob(array(
    'orderby' => 'display_name',
    'order'   => 'ASC',
    'role__in' => [ 'editor' ]
),"المحريين" , false);

addnewusersloob(array(
    'orderby' => 'display_name',
    'order'   => 'ASC',
    'role__in' => [ 'author' ]
),"الكتاب" , false);

addnewusersloob(array(
    'orderby' => 'display_name',
    'order'   => 'ASC',
    'role__in' => [ 'contributor' ]
),"المساهمين" , false);



function addnewusersloob( $args , $roletitle , $def ){
    // جلب المستخدمين بناءً على الإعدادات
    $users = get_users($args);

    // عرض قائمة المستخدمين
    if (!empty($users)) {
        echo '<div class="users_section">';

        echo "<div class='prim_title'><h2> ". $roletitle ." </h2></div>";
        echo '<div class="users-list">';
        $usersads = getoptions('sp_users_mangment');
        $usersarray = $usersads['excludedusers'];
        foreach ($users as $user) {
            $user_id = $user->ID;
            $user_name = $user->display_name;
            $user_url = get_edit_user_link($user_id);
            $user_roles = $user->roles; // جلب الأدوار


            if($def){
                $useractive = isset($usersarray[$user_id]['useractive']) ? $usersarray[$user_id]['useractive'] : '1';
            }else{
                $useractive = isset($usersarray[$user_id]['useractive']) ? $usersarray[$user_id]['useractive'] : '0';
            }
            

            $roles_names = array_map(function($role) {
                return translate_user_role($role);
            }, $user_roles);
            $roles_string = implode(', ', $roles_names);


            // echo isset($usersarray[$user_id]['custom_ratio']);
            echo "  
            <div class='user' data-rol='".esc_html($roles_string)."' data-id='".$user_id."'>
                <label class='switch'>
                    <input type='hidden' class='hide' name='sp_users_mangment[excludedusers][$user_id][useractive]' value='".$useractive."'>
                    <input type='checkbox' " . checked($useractive, '1', false) . ">
                    <span class='slider round'></span>
                </label>
                ". get_avatar( get_the_author_meta('ID') ) ."
                <div class='user_info_ratio'>
                    <a href='" . esc_url($user_url) . "'>".esc_html($user_name)."</a>
                </div>
            </div>
            ";

        }
        echo '</div></div>';
    } else {
        echo "<div class='users_section'> <div class='prim_title'><h2> ". $roletitle ." </h2></div>
        <p class='description'>لا يوجد مستخدمين في هذة الرتبه . </p>
        </div>";
    }

}

    ?>


        </div>

    </div>
<?php

?>
</form>

</div>