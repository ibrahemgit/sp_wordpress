<div class="wrap">

<?php settings_errors();

// delete_option('sp_users_mangment_white_list');

//     $allowed_domains = getoptions('sp_users_mangment_white_list' , 'white_list');
//     $allowed_domains[] = get_site_url();

//     $allowed_domains = array_map(function($url) {
//         $parsed_url = parse_url($url);
//         return isset($parsed_url['host']) ? strtolower($parsed_url['host']) : strtolower($url);
//     }, $allowed_domains);

// echo "<pre>";
// print_r($allowed_domains);
// echo "</pre>";

?>

<form method="post" action="options.php">

    <?php settings_fields( 'seoplus-users-mangment-white-list-group' ); ?>

    <div class='settings_box'>
        <div class='settings_sections'>
            <h1>اعدادات القالب</h1>
            <div class='prim_title'>
            </div>
            <?php submit_button( ); ?>

            <?php do_settings_sections( 'seoplus_users_mangment_white_list' ); ?>
            
            <div class='newFeilds'>
    <?php

    // جلب القائمة البيضاء من قاعدة البيانات
    $white_list = getoptions('sp_users_mangment_white_list', 'white_list');

    // عرض الحقول الحالية مع أزرار الحذف
    foreach($white_list as $index=>$list){
        echo "<div class='input-group' data-index='$index'>
                <input class='regular-text code' type='text' name='sp_users_mangment_white_list[white_list][$index]' value='$list' />
                <button type='button' class='remove-input'>حذف</button>
              </div>";
    }
                    
    // إضافة سكريبت جافاسكريبت لإضافة وحذف الحقول ديناميكياً
    echo "
    <script>
    jQuery(document).ready(function($) {
        let currentMaxIndex = Math.max(0, ...$('.input-group').map(function() {
            return parseInt($(this).data('index'));
        }).get());

        function generateUniqueIndex() {
            return ++currentMaxIndex;
        }

        // إضافة حقل جديد
        $('.addnewurl').click(function(){
            let newIndex = generateUniqueIndex();
            var newinput = $('<div>', { class: 'input-group', 'data-index': newIndex }).append(
                $('<input>', { class: 'regular-text code', type: 'text', name: 'sp_users_mangment_white_list[white_list][' + newIndex + ']', value: '' }),
                $('<button>', { type: 'button', class: 'remove-input', text: 'حذف' })
            );
            $('.newFeilds').append(newinput);
        });

        // حذف حقل
        $(document).on('click', '.remove-input', function(){
            $(this).closest('.input-group').remove();
        });
    });
    </script>
    ";
    ?>
</div>

<span class='addnewurl'>اضف رابط جديد</span>


        </div>

    </div>
<?php

?>
</form>

</div>