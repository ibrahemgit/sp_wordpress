<div class="wrap">

<?php settings_errors(); ?>
        <?php
            // if(get_option( 'sp_minSettings' )){
            //     delete_option('sp_minSettings');
            //     delete_option('sp_header');
            //     delete_option('sp_minColor');
            //     delete_option('sp_aside');
            //     delete_option('sp_lastPosts');
            //     delete_option('sp_postCustom');
            //     delete_option('sp_postFeatures');
            //     delete_option('sp_redirect');
            //     echo "تم استعادة الاعدادات الافتراضيه";
            // }
        ?>
<form method="post" action="options.php">

    <?php settings_fields( 'sp-settings-group-aside' ); ?>

    <div class='settings_box'>
        <div class='settings_sections'>
            <div class='prim_title'>
                <h1>اعدادات القالب</h1>
            </div>
            <?php submit_button( ); ?>

            <?php do_settings_sections( 'seoplus_aside_settings' ); ?>
        </div>
    </div>

</form>

</div>