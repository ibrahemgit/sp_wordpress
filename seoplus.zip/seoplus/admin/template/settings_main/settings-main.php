<div class="wrap">

<?php settings_errors(); ?>
        <?php
            // if(get_option( 'sp_minSettings' )){
                // delete_option('sp_minSettings');
                // delete_option('sp_header');
                // delete_option('sp_minColor');
                // delete_option('sp_aside');
                // delete_option('sp_lastPosts');
                // delete_option('sp_postCustom');
                // delete_option('sp_postFeatures');
                // delete_option('sp_redirect');
                // echo "تم استعادة الاعدادات الافتراضيه";
            // }
        ?>
<form method="post" action="options.php">

    <?php settings_fields( 'sp-settings-group' ); ?>

    <div class='settings_box'>
        <div class='settings_taps'>
            <span class="dashtitle">اعدادات القالب</span>
            <div class='taps'>
                <span class='tap active' data-id='sp_minSettings'>تخصيص الاعدادات الاساسيه</span>
                <span class='tap' data-id='sp_header'>تخصيص القائمه العلوية</span>
                <span class='tap' data-id='sp_minColor'>تخصيص الالوان</span>
                <span class='tap' data-id='sp_aside'>تخصيص القائمه الجانبيه</span>
                <span class='tap' data-id='sp_lastPosts'>تخصيص اخر المشاركات</span>
                <span class='tap' data-id='sp_postCustom'>تخصيص المقالات والصفحات</span>
                <span class='tap' data-id='sp_postFeatures'>مميزات المقالات الاضافية</span>
                <span class='tap' data-id='sp_redirect'>اعادة التوجيه</span>
            </div>
        </div>
        <div class='settings_sections'>
            <div class='prim_title'>
                <h1>اعدادات القالب</h1>
                <?php submit_button( ); ?>
            </div>
            <?php do_settings_sections( 'seoplus_adminpage' ); ?>
            
        </div>
    </div>

</form>

</div>