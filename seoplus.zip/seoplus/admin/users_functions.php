<?php

$sp_author_ads = getoptions('sp_author_ads');

if($sp_author_ads['author_ads_active']){
    
    // عرض الحقول المخصصة في صفحة تحرير العضو
function custom_user_profile_fields($user) {

    $user_roles = $user->roles; // جلب الأدوار
    $roles_names = array_map(function($role) {
        return translate_user_role($role);
    }, $user_roles);
    $roles_string = implode(', ', $roles_names);
    $isContributor = !in_array('contributor', $user_roles) && !in_array('subscriber', $user_roles); 

    
    $sp_author_ads = getoptions('sp_author_ads');
    $useroption = $sp_author_ads['users'];
    
    

    

    $is_active = isset($useroption[$user->ID]['useractive']) ? $useroption[$user->ID]['useractive'] : $isContributor ;

    if($is_active) : // start if cond
    $adsense = get_user_meta($user->ID, 'adsense', true);
    $client = isset($adsense['client']) ? esc_attr($adsense['client']) : '';
    $channel = isset($adsense['channel']) ? esc_attr($adsense['channel']) : '';
    $slot = isset($adsense['slot']) ? esc_attr($adsense['slot']) : '';
    $url = isset($adsense['url']) ? esc_attr($adsense['url']) : '';
    $ratio = isset($useroption[$user->ID]['custom_ratio']) ? esc_attr($useroption[$user->ID]['custom_ratio']) : esc_attr($sp_author_ads['author_ratio']);
    ?>
    <table class="form-table">
        <h3>معلومات AdSense</h3>
        <tr>
            <th><label for="adsense_client">معرف حساب جوجل أدسنس</label></th>
            <td>
                <input type="text" name="adsense[client]" id="adsense_client" value="<?php echo esc_attr($client); ?>" class="regular-text" />
            </td>
        </tr>
        <tr>
            <th><label for="adsense_phone">رقم القناة المخصصة (اختياري)</label></th>
            <td>
                <input type="text" name="adsense[channel]" id="adsense_phone" value="<?php echo esc_attr($channel); ?>" class="regular-text" />
            </td>
        </tr>
        <tr>
            <th><label for="adsense_phone">الرقم التعريفي للوحدة الإعلانية (اختياري)</label></th>
            <td>
                <input type="text" name="adsense[slot]" id="adsense_phone" value="<?php echo esc_attr($slot); ?>" class="regular-text" />
            </td>
        </tr>
        <tr>
            <th><label for="adsense_phone">رابط الموقع (اختياري)</label></th>
            <td>
                <input type="text" name="adsense[url]" id="adsense_phone" value="<?php echo esc_attr($url); ?>" class="regular-text" />
            </td>
        </tr>
        <tr>
            <th><label for="adsense_phone">نسبة ظهور إعلاناتك</label></th>
            <td>
                <?php echo $ratio . '%'; ?>
            </td>
        </tr>
    </table>
    <?php
endif; // end if cond
}
add_action('show_user_profile', 'custom_user_profile_fields');
add_action('edit_user_profile', 'custom_user_profile_fields');

// حفظ الحقول المخصصة
function save_custom_user_profile_fields($user_id) {
    if (!current_user_can('edit_user', $user_id)) {
        return false;
    }

    check_admin_referer('update-user_' . $user_id);

    $adsense = array(
        'client' => sanitize_text_field($_POST['adsense']['client']),
        'channel' => sanitize_text_field($_POST['adsense']['channel']),
        'slot' => sanitize_text_field($_POST['adsense']['slot']),
        'url' => sanitize_text_field($_POST['adsense']['url']),
    );


    
    update_user_meta($user_id, 'adsense', $adsense);



    // add new user
    $all_adsense_data = getoptions('sp_author_ads');
    if(!isset($all_adsense_data['users'][$user_id]) && $all_adsense_data['author_ads_active']){
        $user = get_userdata($user_id);
        if ($user) { // جلب الأدوار
            $user_roles = $user->roles; 
            $roles_names = array_map(function($role) {
                return translate_user_role($role);
            }, $user_roles);
            $roles_string = implode(', ', $roles_names);
            $isContributor = !in_array('contributor', $user_roles) && !in_array('subscriber', $user_roles);
            if($isContributor){
                $all_adsense_data['users'][$user_id] = array('useractive' => 1);
                update_option('sp_author_ads', $all_adsense_data);
            }
        }
    } // end



    function update_ads_txt_file() {
        // الحصول على محتوى الخيار القديم
        $get_old_ads_txt = getoptions('sp_ads_txt');
    
        // تنظيف المدخلات
        $adsense_client = sanitize_text_field($_POST['adsense']['client']);
    
        // تحقق من عدم وجود العميل بالفعل في النص القديم
        $old_ads_client = !str_contains($get_old_ads_txt['ads_text_area'], $adsense_client);
    
        if (!empty($adsense_client) && $old_ads_client) {
            // إعداد النص الجديد
            $new_ads_txt = "google.com, " . $adsense_client . ", DIRECT, f08c47fec0942fa0\n";
            $new_content = $new_ads_txt . $get_old_ads_txt['ads_text_area'] ;
    
            // تحديث الخيار
            $new_array = array(
                'ads_text_active' => $get_old_ads_txt['ads_text_active'],
                'ads_text_area' => $new_content,
            );
    
            // تحديث الخيار في قاعدة البيانات
            $update_success = update_option('sp_ads_txt', $new_array);
    
            // التحقق من جاهزية نظام الملفات
            if ($update_success && !function_exists('WP_Filesystem')) {
                require_once(ABSPATH . 'wp-admin/includes/file.php');
            }
    
            // إعداد نظام الملفات
            $creds = request_filesystem_credentials('', '', false, false, array());
    
            if (!WP_Filesystem($creds)) {
                return; // إنهاء إذا لم يتم تهيئة النظام
            }
    
            global $wp_filesystem;
    
            // كتابة المحتوى الجديد إلى الملف
            if (is_object($wp_filesystem) && $wp_filesystem->put_contents(ABSPATH . 'ads.txt', $new_content, FS_CHMOD_FILE)) {
                error_log('Successfully updated ads.txt');
            } else {
                error_log('Failed to update ads.txt');
            }
        }
    }
    
    # run file system
    update_ads_txt_file();
    
}
add_action('personal_options_update', 'save_custom_user_profile_fields');
add_action('edit_user_profile_update', 'save_custom_user_profile_fields');




// إضافة أعمدة مخصصة إلى جدول الأعضاء
function custom_user_columns($columns) {
    $columns['sp_user_ads'] = 'مشاركة الارباح';
    return $columns;
}
add_filter('manage_users_columns', 'custom_user_columns');

// عرض القيم في الأعمدة المخصصة
function custom_user_columns_data($value, $column_name, $user_id) {
    $adsense = get_user_meta($user_id, 'adsense', true);
    if(is_array($adsense)){
        if ($column_name == 'sp_user_ads') {
            $HTML = '<div style="direction: ltr; text-align: left;">';
            if(isset($adsense['client']) && !empty($adsense['client'])){
                $HTML .= "<p> pub: <input type='text' class='sp_user_ads_input' readonly value='".esc_html($adsense['client'])."'></p>";
            }
            if(isset($adsense['channel']) && !empty($adsense['channel'])){
                $HTML .= "<p> channel: <input type='text' class='sp_user_ads_input' readonly value='".esc_html($adsense['client'])."'></p>";
            }
            if(isset($adsense['slot']) && !empty($adsense['slot'])){
                $HTML .= "<p> slot: <input type='text' class='sp_user_ads_input' readonly value='".esc_html($adsense['slot'])."'></p>";
            }
            if(isset($adsense['url']) && !empty($adsense['url'])){
                $HTML .= "<p> url: <input type='text' class='sp_user_ads_input' readonly value='".esc_html($adsense['url'])."'></p>";
            }
            $HTML .= "</div>";
            return $HTML;
        }
    }
    return $value;
}

add_action('manage_users_custom_column', 'custom_user_columns_data', 10, 3);

}
