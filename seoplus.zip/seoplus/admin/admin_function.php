<?php


function getoptions($key ="",$name = ""){

    $sp_users_mangment_white_list = array(
        'white_list'                               => array(),
    );
    $sp_users_mangment = array(
        'users_mangment_is_active'                       => 0,
        'users_mangment_tapel'                       => 1,
        'excludedusers'                               => array(),
    );

    $sp_ads_txt = array(
        'ads_text_active'                       => 1,
        'ads_text_area'                       => 'text here',
    );

    $sp_author_ads = array(
        'author_ads_active'                             => 0,
        'author_ratio'                             => '80',
        'users'                               => array(),
    );


    $sp_theme_ads = array(
        'adsactive'                             => 0,
        'adsensepub'                            => '',
        'userAds'                               => array(),
    );

    $sp_minSettings = array(
        'postTime'                                  => 0,
        'themeStyle'                                  => 0,
        'rmpostscat'                                  => 0,

        'QuickAccessMenu'                       => 'one',
        'darkmain'                           => 0,
        'disableDark'                           => 0,
        'changeDark'                           => 0,
        'coverImg'                              => 1,
        'stopCopying'                           => 0,

        'siteWidth'                             => '1100',
        'sidebarWidth'                          => '330',
    );

    $sp_header = array(
        'logoUrl'                               => '',
        'HeaderStyle'                           => 'one',
        'stickyHeader'                          => 0,
        'linkFontSize'                          => '15',
        'SearchButton'                          => 'true',
        'headerBg'                              => '#ffffff',
        'linkColor'                             => '#444444',
        'SearchButtonBg'                        => '#035dcd',
        'SearchButtonIc'                        => '#ffffff',
    );

    $sp_minColor = array(        
        'bodyBg'                                => '#f7f7f7',
        'keyColor'                              => '#035dcd',
        'stepColor'                             => '#eeeeee',
        'gradColor'                             => '#ffffff',
        'textColor'                             => '#34495e',
    );

    $sp_aside = array(        
        'home'                                  => 0,
        'post'                                  => 0,
        'page'                                  => 0,
        'mobile'                                => 0,
    );

    $sp_lastPosts = array(        
        'style'                                 => 'Sp-postsnew0',
        'loadMore'                              => 'one',
        'disaple'                               => 0,
    );

    $sp_postCustom = array(        
        'titleColor'                                    => '#171921',
        'titleSize'                                     => '30',
        'contentColor'                                  => '#222222',
        'contentSize'                                   => '18',
        'contentURLColor'                               => '#062C73',
    );

    $sp_postFeatures = array(

        'postRandomActive'                          => 1,
        'postRandom'                                => 'Sp-posts6',
        'postRandomNumper'                          => 3,
        'postRandomIsRand'                          => 1,
        
        'retPostsActive'                            => 1,
        'retPostsNumper'                            => 3,
        'retPosts'                                  => 'Sp-posts6',
        'retPostsIsRand'                          => 0,

        'removeAuthor'                              => 0,
    );

    $sp_redirect = array(
        'isActicve'                             => 0,
        'isPageId'                             => '',
        'isTimer'                               => '10',
        'isProtection'                          => 1,
        'isPopup'                               => 0,
        'isSkin'                                => 0,
        'skinStyle'                             => 'one',
        'autoRedirect'                          => 0,
        'textConfigure'                         => 'جاري تهيئة الرابط',
        'textReady'                             => 'الرابط جاهز',
        'textError'                             => 'رابط معطل',
        'blockList'                             => '',
    );

    if (empty($name)) {
        $option_value = get_option($key, $$key);
    } else {
        $option_value = get_option($key, $$key);
        // تحقق من وجود المفتاح في المصفوفة
        if (isset($option_value[$name])) {
            return $option_value[$name];
        } else {
            return $$key[$name]; // أو أي قيمة افتراضية أخرى
        }
    }
    return $option_value;

}

# to send array

function setting_fields($nameId, $array, $group, $option, $admin){

    register_setting($group, $nameId, array('type' => 'array'));

    foreach($array as $arr){

        $name = $arr['name'];
        $title = $arr['title'];
        $type = $arr['type'];
        $arrkey = $nameId . '['.$name.']';

        add_settings_field($name, $title, function () use($arr,$arrkey,$name,$nameId,$type){
            if($type == "switch"){
                echo "
                <label class='switch'>
                    <input type='hidden' class='hide' name='$arrkey' value='". getoptions($nameId, $name) ."'>
                    <input value='false' id='$name' type='checkbox' ". checked( getoptions($nameId, $name) , 1, false) .">
                    <span class='slider round'></span>
                </label>
                ";
            }elseif($type == "switch-ad"){
                echo "
                <label class='switch'>
                    <input type='hidden' class='hide' name='$arrkey' value='". getoptions($nameId, $name) ."'>
                    <input value='false' id='$name' type='checkbox' ". checked( getoptions($nameId, $name) , 1, false) .">
                    <span class='slider round'></span>
                </label>
                <textarea class='large-text code' name='$arrkey'>".  getoptions($nameId, $name) ."</textarea>
                ";
            }elseif($type == "image"){
                echo "
                    <input class='regular-text code imginput' id='$arrkey' type='text' name='$arrkey' value='". getoptions($nameId, $name) ."' />
                    <input type='button' class='button button-secundary uploadButton' value='رفع'/>
                    <img class='imagePriv' src='". getoptions($nameId, $name) ."'>
                ";
            }elseif($type == "text"){
                echo " <input class='regular-text code' type='text' name='$arrkey' value='".  getoptions($nameId, $name) ."' /> ";
            }elseif($type == "color"){
                echo "
                    <input type='color' id='$name' name='$arrkey' value='".  getoptions($nameId, $name) ."'>
                    <label for='$name'>اختر اللون</label>
                ";
            }elseif($type == "textarea"){
                echo "
                    <textarea class='large-text code' name='$arrkey'>".  getoptions($nameId, $name) ."</textarea>
                ";
            }elseif($type == "select_pages"){
                $op = getoptions($nameId, $name);
                $pages = get_pages();
                $output = "<select name='$arrkey' id='$name'>";
                foreach ($pages as $page) {
                    $output .= '<option value="' . esc_attr($page->ID) . '" '.selected( $op , $page->ID , false).'>' . esc_html($page->post_title) . '</option>';
                }
                $output .= '</select>';
                if(!empty($op)){
                    $output .= "<a href='".esc_url(get_edit_post_link($op))."' class='but'>تعديل الصفحة</a>";
                }
                echo $output;
            }elseif($type == "radio"){

                echo "<div class='sp_radioObject'>";
                    foreach($arr['SubArray'] as $Sarr){
                        $value = $Sarr['value'];
                        $image = $Sarr['image'];
                        $text = $Sarr['text'];
                        echo "
                        <div class='sp_radio_input'>
                            <label>
                                <input type='radio' name='$arrkey' value='$value' ".(getoptions($nameId, $name) === "$value" ? "checked" : "").">
                                <img src='$image'>
                                <span>$text</span>
                            </label>
                        </div>
                        ";
                    }
                echo "</div>";

            }elseif($type == "range"){
                $min = (array_key_exists('min', $arr) ? $arr['min'] : '0');
                $max = (array_key_exists('max', $arr) ? $arr['max'] : '1');
                echo "
                <input type='range' name='$arrkey' value='".  getoptions($nameId, $name) ."' min='$min' max='$max' oninput='this.nextElementSibling.value = this.value' />
                <output>".  getoptions($nameId, $name) ."</output>
                ";
            }elseif($type == "number"){
                $min = (array_key_exists('min', $arr) ? $arr['min'] : '0');
                $max = (array_key_exists('max', $arr) ? $arr['max'] : '1');
                echo "
                <input type='number' name='$arrkey' value='".  getoptions($nameId, $name) ."' min='$min' max='$max' value='". getoptions($nameId, $name) ."' />
                ";
            }
        } , $admin, $option, array('class' => $name));

    }
    
}
