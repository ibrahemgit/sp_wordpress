<?php


/*
	Popular Posts Widget
*/
function return_class($variable, $value_to_compare, $class_to_return) {
    return ($variable === $value_to_compare) ? $class_to_return : '';
}

class Seoplus_Posts_Widget extends WP_Widget {
	
	//setup the widget name, description, etc...
	public function __construct() {
		
		$widget_ops = array(
			'classname' => 'seoplus-posts-by-tags-widget',
			'description' => 'Seoplus posts by tags widget',
		);
		parent::__construct( 'seoplus_posts_by_tags', 'Seoplus posts by tags', $widget_ops );
		
	}
	
	// back-end display of widget
	public function form( $instance ) {
	
        $title = !empty( $instance[ 'title' ] ) ? $instance[ 'title' ] : 'أخر المقالات';
        $postcat = !empty( $instance[ 'postcat' ] ) ? $instance[ 'postcat' ] : 'LastPosts';
        $tot = !empty( $instance[ 'tot' ] ) ? absint( $instance[ 'tot' ] ) : 4;
        $stylecs = !empty( $instance[ 'stylecs' ] ) ? $instance[ 'stylecs' ] : "Sp-posts1";
        $lapelid = !empty( $instance[ 'lapelid' ] ) ? $instance[ 'lapelid' ] : '1';
        $randomly = !empty( $instance[ 'randomly' ] ) ? $instance[ 'randomly' ] : '';

        $output = '<p>';
        $output .= '<label for="' . esc_attr( $this->get_field_id( 'title' ) ) . '">العنوان :</label>';
        $output .= '<input type="text" class="widefat" id="' . esc_attr( $this->get_field_id( 'title' ) ) . '" name="' . esc_attr( $this->get_field_name( 'title' ) ) . '" value="' . esc_attr( $title ) . '">';
        $output .= '</p>';
        
        $output .= '<p class="articalelength">';
        $output .= '<label for="' . esc_attr( $this->get_field_id( 'tot' ) ) . '">عدد المقالات :</label>';
        $output .= '<input type="number" min="1" max="20" class="widefat" id="' . esc_attr( $this->get_field_id( 'tot' ) ) . '" name="' . esc_attr( $this->get_field_name( 'tot' ) ) . '" value="' . esc_attr( $tot ) . '">';
        $output .= '</p>';
        
        $output .= '<p>';
        $output .= '<label for="' . esc_attr( $this->get_field_id( 'postcat' ) ) . '">مصدر المقالات :</label>';
        $output .= '<select class="widefat articlesoruce" id="' . esc_attr( $this->get_field_id( 'postcat' ) ) . '" name="' . esc_attr( $this->get_field_name( 'postcat' ) ) . '">';
        $output .= '<option value="LastPosts" '. selected( $postcat, 'LastPosts', false ) .'> أخر المبشاركات </option>';
        $output .= '<option value="byCategory" '. selected( $postcat, 'byCategory', false ) .'> من تصنيف محدد </option>';
        $output .= '</select>';
        $output .= '</p>';

        $showCats = ($postcat == "byCategory" ? "show" : "hide");

        $output .= '<select class="widefat getcats '.$showCats.'" id="' . esc_attr( $this->get_field_id( 'lapelid' ) ) . '" name="' . esc_attr( $this->get_field_name( 'lapelid' ) ) . '">';
        $categories = get_categories();
        foreach($categories as $category) {
            $output .= '<option value="'.$category->term_id.'" '. selected( $lapelid, $category->term_id, false ) .'>'.$category->name.' ('.$category->count.') </option>';
        }
        $output .= '</select>';

        $output .= '<p>';
        $output .= '<input type="checkbox" id="'. esc_attr( $this->get_field_id( 'randomly' ) ) .'" name="'. esc_attr( $this->get_field_name( 'randomly' ) ) .'" value="true" '.checked($randomly, 'true', false).'><label for="'. esc_attr( $this->get_field_id( 'randomly' ) ) .'"> مقالات عشوائية</label><br>';
        $output .= '</p>';

        $output .= '<div class="selectStyle">';
        $output .= '<label for="' . esc_attr( $this->get_field_id( 'stylecs' ) ) . '">شكل المقالات :</label>';
		
		$output .= '<div class="adwid">';

		$output .= "
					<label class='sp_radio_input_wid ".return_class($stylecs, 'Sp-slide', 'checked')."'>
						<input class='radio' type='radio' name='". esc_attr( $this->get_field_name( 'stylecs' ) ) ."' value='Sp-slide' ".checked($stylecs, 'Sp-slide', false).">
						<img src='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj77YJTXbxAiyD26BRUF4AWnE0TwXJ16yFo46MLiPpT26-2oG8DvQwrcspe1surnC0xtRP5ghQFX4BTKlCFnJP8XuLkKzwc607iQgcKnPykMoGcJ1TbTs8-AvHZa0cS5etM677u5ayoI9O1n4EHaRRGijY1xpDGLO1F4JJwrBWHnxBRx1PrFn2rnvJf/s1600/slide1.png'>
						<span>السلايد الاول</span>
					</label>

					<label class='sp_radio_input_wid ".return_class($stylecs, 'Sp-slide2', 'checked')."'>
						<input class='radio' type='radio' name='". esc_attr( $this->get_field_name( 'stylecs' ) ) ."' value='Sp-slide2' ".checked($stylecs, 'Sp-slide2', false).">
						<img src='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgzFLb9l5QtAF0dBbTzyztuhDR6-aBnObtPumLtqDStRXOhMJYSfskmOMlVubhBC5JNfsORg3805ZMa0ROsv80I5OWNDWA18hBl1OpUN-HtetWqWE7HaN2j5SzwOfnMqrFZsYyonMjlOQUyk9EP7jVhzrCg7ydvvd5-AWbc6OMnAWWb2_Ggy0l2g-Vf/s1600/slide2.png'>
						<span>السلايد الثاني</span>
					</label>

					<label class='sp_radio_input_wid ".return_class($stylecs, 'Sp-slide3', 'checked')."'>
						<input class='radio' type='radio' name='". esc_attr( $this->get_field_name( 'stylecs' ) ) ."' value='Sp-slide3' ".checked($stylecs, 'Sp-slide3', false).">
						<img src='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiK4tmWycpNojptIMnyFJjyFqD0abTcVTai7iYXE_sFXujwz5h1cKXL5BqHHuljPP8vh8VyzpNL_Cl4UOPLQG1U0qvcIgsSKxBSuxCk446jKJ8733uobu0Y8iEtjmPqzFtGIuaah6f3Pv_cWvFE0p5Ou8jnZyt9WBBERCG2TAyXP9rky3pnuEFTSQTs/s1600/slide3.png'>
						<span>السلايد الثالث</span>
					</label>

					<label class='sp_radio_input_wid ".return_class($stylecs, 'Sp-slide4', 'checked')."'>
						<input class='radio' type='radio' name='". esc_attr( $this->get_field_name( 'stylecs' ) ) ."' value='Sp-slide4' ".checked($stylecs, 'Sp-slide4', false).">
						<img src='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEh9FQoRl1CW7lc9j5dInAgb34SWwj3hNNCmysaIQ3YzQNotLKSy4whQtSH3toxvr8M3J6IEg9SYT8MYTqwRHcd-XNBuuJE2WvlklBXX6xGOP-3QT4u6E-yDvL7EM9CNYr68ASUVDtFXpHWXgjQQIOSRD2eqz-dDvgW-P4XinBYYKzoapBSavR9dYyat/s1600/slide4.png'>
						<span>السلايد الرابع</span>
					</label>

					<label class='sp_radio_input_wid ".return_class($stylecs, 'Sp-posts1', 'checked')."'>
						<input class='radio' type='radio' name='". esc_attr( $this->get_field_name( 'stylecs' ) ) ."' value='Sp-posts1' ".checked($stylecs, 'Sp-posts1', false).">
						<img src='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgWwthj87DJjjvGlOb5cWfyHTig1oL1WHAtO4qFqxlTVYYqBb3tIcA-AKpViSR_fPYSxENmpSMe9RxYdiNRw5Mbhti3zXjhdzE4H_DswJ6c3N8SAe_N4UHcVkeg6NhFWQYR6igqhyLetDXroQvkS55b8r_yTSe7Nmmhz-hP2-u1bLw4dLSRc6Ufnrbm/s1600/post1.png'>
						<span>الشكل الاول</span>
					</label>

					<label class='sp_radio_input_wid ".return_class($stylecs, 'Sp-posts2', 'checked')."'>
						<input class='radio' type='radio' name='". esc_attr( $this->get_field_name( 'stylecs' ) ) ."' value='Sp-posts2' ".checked($stylecs, 'Sp-posts2', false)." >
						<img src='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi3u61GXpCAX-acX6gZXVrun13HuCLxHe2yX5G0jkwKPU4ZpKI5VoUb2IyTdMGqnciY8jRoDHtS4D5fxPU_9x9uPulFe-H67VaAKOnT6UCPaXo0mP-FVop4fIhIlpJeXWCkcR81VGotrANxxPBSQedLvXKInCIBYIOg1uzG7PWOA_0EcAgo7btktbq5/s1600/post2.png'>
						<span>الشكل الثاني</span>
					</label>
				
					<label class='sp_radio_input_wid ".return_class($stylecs, 'Sp-posts3', 'checked')."'>
						<input class='radio' type='radio' name='". esc_attr( $this->get_field_name( 'stylecs' ) ) ."' value='Sp-posts3' ".checked($stylecs, 'Sp-posts3', false)." >
						<img src='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjEkBZFZxQe1i8YTRJNgUsLXkY1vpJL404TDauhgDrGjDJ5MPlcUxG51MEgW63Bcan1aPi0Yxd8AXNW_blqK4G0BRD99sK-eRSGqa66A2LOVC_f-eY8YmGuTFkw03XE46NCOPLdPjGbkNlTTqJj_UcNkvDOpbLUgYVAp7hRvQqbBZEwFqafutEh_PKM/s1600/post3.png'>
						<span>الشكل الثالث</span>
					</label>
				
					<label class='sp_radio_input_wid ".return_class($stylecs, 'Sp-posts4', 'checked')."'>
						<input class='radio' type='radio' name='". esc_attr( $this->get_field_name( 'stylecs' ) ) ."' value='Sp-posts4' ".checked($stylecs, 'Sp-posts4', false)." >
						<img src='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhXChU1MNoJeGxXvTZNNNIfr1udJ9zL4wazWEOau0HFZP8UKUc0u53U8qp3S7CcxRYBp4-sHLrYWVEIMzQoPv7WDRGXh_4HVsL3IbH675mdcdSaOnqmjwMu5i3KNQRILyQQkFTix5hgFwgDRKTUVq9_7st_PaPwQrTkUBh7LzncjdrYp6VR-ps8wI3i/s1600/post4.png'>
						<span>الشكل الرابع</span>
					</label>

					<label class='sp_radio_input_wid ".return_class($stylecs, 'Sp-posts5', 'checked')."'>
						<input class='radio' type='radio' name='". esc_attr( $this->get_field_name( 'stylecs' ) ) ."' value='Sp-posts5' ".checked($stylecs, 'Sp-posts5', false)." >
						<img src='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg6yGbQJtfSadJKF9THYSPghg05KsegJbVoY5vyEYG-KOQF3IG-aFoSIQmJIHoZ_Sw4V7NLMp5Gc4N4nH5dWFX7C4VJ7Z55JZMeQZOy3wgXz4vRkN4lwW2Kxu0AVNfWFXdjF-85TDkhDtr_xpNulO3bN8nPeRcS3-dXrmYAxcckBHsWj7QJNX15_3Bo/s1600/post5.png'>
						<span>الشكل الخامس</span>
					</label>

					<label class='sp_radio_input_wid ".return_class($stylecs, 'Sp-posts6', 'checked')."'>
						<input class='radio' type='radio' name='". esc_attr( $this->get_field_name( 'stylecs' ) ) ."' value='Sp-posts6' ".checked($stylecs, 'Sp-posts6', false)." >
						<img src='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhN4esgn_U3ZYdst1ppo8lkRHc4lARQ7CLbGlCV3L2jyxT21yXwQdkGdqDE86E9NJTF7VZW_jthCBrDox9AMuCGWglRQ42Afop9UB1YyDYgHl0Ky4nsoxtYilYD4VE2KJLM9lQRJqmgn4JyJytUVA5S7NqnID0AZbeJxgEGIE3UDM_2-9v-47EwRzwQ/s1600/post6.png'>
						<span>الشكل السادس</span>
					</label>

					<label class='sp_radio_input_wid ".return_class($stylecs, 'Sp-posts7', 'checked')."'>
						<input class='radio' type='radio' name='". esc_attr( $this->get_field_name( 'stylecs' ) ) ."' value='Sp-posts7' ".checked($stylecs, 'Sp-posts7', false)." >
						<img src='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiETqbPr9nyytNG19pX_fZLc9L-QgyAi19Wcv4Lo7U5x7l5KXraE0RTRFhXTXJfObjd2UeIKRm601oWSw-iZtPdgMlxOyiG30DhrsdXOn0NTWUu4badL3dOWRsqqjVLtrEult0AvmMgQ9LomIcR3egYgu2bFkumG8s1-ssDRqKJBj4sOgu7QcF7wzJl/s1600/post7.png'>
						<span>الشكل السابع</span>
					</label>

					<label class='sp_radio_input_wid ".return_class($stylecs, 'Sp-postsnew', 'checked')."'>
						<input class='radio' type='radio' name='". esc_attr( $this->get_field_name( 'stylecs' ) ) ."' value='Sp-postsnew' ".checked($stylecs, 'Sp-postsnew', false)." >
						<img src='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg0pDXa5aXUT2GkB3jXmDOz5nr4wHY4hQFXDHar6ZCLvS-KTwpWeA6eyXGKad2G8a1nsboBYbpjsHeF7ycoTPxa3xLraXTrtBzA5xVG4vz5DM2s79-Uu4nkHlAI8lv8elTe6h1AOU3cs0AqN192yeL0q9l8CY-g5t9qkpEeIrLYLOzQeO6RHQ76mOrH/s1600/postnew1.png'>
						<span>الشكل postsnew</span>
					</label>

					<label class='sp_radio_input_wid ".return_class($stylecs, 'Sp-postsnew0', 'checked')."'>
						<input class='radio' type='radio' name='". esc_attr( $this->get_field_name( 'stylecs' ) ) ."' value='Sp-postsnew0' ".checked($stylecs, 'Sp-postsnew0', false)." >
						<img src='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi9rlAEN-0FSvojauKrBokx7xb3j1xoCRDvdlu9UQ1DxrYzGDTehnyGttEin6kUM3YgXQQd7gv4DZ87qqaKSoL5CmjGeYT85_SOxnvuOQhJUbBtFAc8F5U2Dhcncbjjb5j-4Jkla6DDIvttqVIReNXKvFy-KlsyIsnPsiOjbg-4ZEQGLgaw6n4Hm772/s1600/postnew0.png'>
						<span>الشكل postsnew0</span>
					</label>

					<label class='sp_radio_input_wid ".return_class($stylecs, 'Sp-3colList', 'checked')."'>
						<input class='radio' type='radio' name='". esc_attr( $this->get_field_name( 'stylecs' ) ) ."' value='Sp-3colList' ".checked($stylecs, 'Sp-3colList', false)." >
						<img src='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjUrYVE8jn5ew14y33GLSnQb5au8tdy-b072-ETgVAE9-sXeGaLRL8ahDVBs0GFFaLG29WJeTHVsi-Bp9bQ15HHczX6vtsxS3mikpn7LNqtOTjVFxbL8PJVxkuAcwtbVz2sztigNXYopGIfZ4c2Ko1HUpTQJOyzndZdRZ8CJTUSzT6CELWQjmrrF53S/s1600/3collist.png'>
						<span>الشكل 3colList</span>
					</label>
					";

		$output .= '</div>';
		$output .= '</div>';


		echo $output;
		
	}
	
	//update widget
	public function update( $new_instance, $old_instance ) {
		
		$instance = array();
		$instance['title'] = !empty($new_instance['title']) ? strip_tags($new_instance['title']) : '';
		$instance['postcat'] = !empty($new_instance['postcat']) ? strip_tags($new_instance['postcat']) : '';
		$instance['tot'] = !empty($new_instance['tot']) ? absint($new_instance['tot']) : 4;
		$instance['stylecs'] = !empty($new_instance['stylecs']) ? strip_tags($new_instance['stylecs']) : 'Sp-posts1';
		$instance['lapelid'] = !empty($new_instance['lapelid']) ? strip_tags($new_instance['lapelid']) : '1';
		$instance['randomly'] = !empty($new_instance['randomly']) ? strip_tags($new_instance['randomly']) : '';
		
		return $instance;
			
	}
	
	//front-end display of widget
	public function widget( $args, $instance ) {
		$tot = absint( $instance[ 'tot' ] );

		if($instance[ 'postcat' ] == 'LastPosts') :
            $Arg = array(
                'post_type'			=> 'post',
                'posts_per_page'	=> $tot,
            );
			else :
				$Arg = array(
					'post_type'			=> 'post',
					'posts_per_page'	=> $tot,
					'cat' => $instance[ 'lapelid' ],
				);
			endif;
			
		if((bool) $instance['randomly']){
			$Arg['orderby'] = 'rand';
		}

		$post_tag = new WP_Query($Arg);
		$titleURL = '<a class="Lapel-Link" href="'. get_category_link($instance[ 'lapelid' ]) .'">عرض المزيد</a>';
		$args[ 'after_title' ] = "</h2> <span class='line'></span> $titleURL </div>" ;

		// $catbutton = get_category_link( get_cat_ID( $instance[ 'postcat' ] ) );

		_e('<div class="widget">');
		// echo $args[ 'before_widget' ];
		if( !empty( $instance[ 'title' ] ) ):
			echo $args[ 'before_title' ] . apply_filters( 'widget_title', $instance[ 'title' ] ) . $args[ 'after_title' ];
			// echo $args[ 'before_title' ] . "<h2 class='title'>" .apply_filters( 'widget_title', $instance[ 'title' ] ) . "</h2>" . $titleURL . $args[ 'after_title' ];
		endif;
		if( $post_tag->have_posts() ):
			_e('<div class="'.$instance['stylecs'].'"><section class="Posts-byCategory">');
			while($post_tag->have_posts()): $post_tag->the_post(); 
				get_template_part('postsTemplate' , null , array($post_tag->current_post));
			endwhile;
			_e('</section></div>');
		endif;
		// echo $args[ 'after_widget' ];
		_e('</div>');
		wp_reset_query();
	}
	
}

add_action( 'widgets_init', function() {
	register_widget( 'Seoplus_Posts_Widget' );
} );

