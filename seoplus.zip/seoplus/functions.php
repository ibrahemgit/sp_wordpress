<?php


function seoplus_files(){
if(is_single() || is_page()){
    wp_enqueue_style('main-post', get_template_directory_uri() . '/css/main-post.css');
}
    wp_enqueue_style('main-style', get_template_directory_uri() . '/css/main-style.css');

    wp_enqueue_style('header-main', get_template_directory_uri() . '/css/header-main.css');

    if(getoptions("sp_header", "HeaderStyle") == "one"){
        wp_enqueue_style('header-1', get_template_directory_uri() . '/css/header-1.css');
    }
    if (getoptions("sp_header", "HeaderStyle") == "tow") {
        wp_enqueue_style('header-2', get_template_directory_uri() . '/css/header-2.css');
    }
    if (getoptions("sp_header", "HeaderStyle") == "tree") {
        wp_enqueue_style('header-3', get_template_directory_uri() . '/css/header-3.css');
    }
        
    /* post_tags_css */
    wp_enqueue_style('post_tags_css', get_template_directory_uri() . '/css/post_tags_css.css');
    
    wp_enqueue_style('post-tags-css-home-only', get_template_directory_uri() . '/css/post-tags-css-home-only.css');
    wp_enqueue_style('post-tags-css-home-post', get_template_directory_uri() . '/css/post-tags-css-home-post.css');
    wp_enqueue_style('post-tags-css-responsev', get_template_directory_uri() . '/css/post-tags-css-responsev.css');

    /* js files */
    wp_enqueue_script('main-scripts', get_template_directory_uri() . '/js/main-scripts.js', array(), false, true);

}

add_action( 'wp_enqueue_scripts', 'seoplus_files');



function build_sidepar(){
    register_sidebars( 16, [
        'name' => 'Post Section %d',
        'id'   => 'post_section',
    
        'description'  => 'هذا القسم يظهر فقط في الصفحة الرئيسية',
        'before_title' => '<div class="headline"><h2 class="title">',
        'after_title' => '</h2><span class="line"></span></div>'
    ] );
    register_sidebars( 4, [
        'name' => 'footer Section %d',
        'id'   => 'sp_footer',
    
        'description'  => 'هذا القسم يظهر فقط في الصفحة الرئيسية',
        'before_title' => '<div class="headline"><h2 class="title">',
        'after_title' => '</h2><span class="line"></span></div>'
    ] );
    
    register_sidebar(array(
        'name' => 'main Sidepar',
        'id' => 'min-sidebar',
        'class' => 'Sidepar',
        'description' => 'main Sidepar Build by me',
        'before_title' => '<div class="headline"><h2 class="title">',
        'after_title' => '</h2><span class="line"></span></div>'
    ));
}

add_action( 'widgets_init', 'build_sidepar');


function seoplus_setup(){
    add_theme_support( 'custom-background' );
    add_theme_support( 'custom-header' );
    // add_theme_support('post-formats',array('aside','image','video'));
    
    add_theme_support( 'title-tag' );
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'post-thumbnails' );
    set_post_thumbnail_size( 1568, 9999 );
    add_theme_support( 'html5', array( 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets', ));
    add_theme_support( 'customize-selective-refresh-widgets' );
    add_theme_support( 'wp-block-styles' );
    add_theme_support( 'align-wide' );
    
    // Add support for responsive embedded content.
    add_theme_support( 'responsive-embeds' );
    
    // Add support for custom line height controls.
    add_theme_support( 'custom-line-height' );
    
    // Add support for experimental link color control.
    add_theme_support( 'experimental-link-color' );
    
    // Add support for experimental cover block spacing.
    add_theme_support( 'custom-spacing' );
    
    // Add support for custom units.
    // This was removed in WordPress 5.6 but is still required to properly support WP 5.5.
    add_theme_support( 'custom-units' );
}

add_action( 'after_setup_theme', 'seoplus_setup' );


function post_post_image(){
    
    // if( has_post_thumbnail() ) :
    //     the_post_thumbnail('', ['class' => 'post-thumb','title' => 'Post Img']);
    // else:
    //     echo '<img src="" title"No Image" alt"No Image">';
    // endif;

    if ( has_post_thumbnail() ) {
        the_post_thumbnail('', ['class' => 'post-thumb','title' => 'Post Img']);
      } else {
       echo '<img src="';       
       echo catch_that_image();
       echo '" alt=""  />';
    }
}
function catch_that_image() {
    global $post, $posts;
    $first_img = '';
    $output = preg_match_all('/<img.+?src=[\'"]([^\'"]+)[\'"].*?>/i', $post->post_content, $matches);
    
    if(empty($matches[1][0])) {
        $first_img = "https://1.bp.blogspot.com/-QK7ox5j6x70/X9aUSEEyj7I/AAAAAAAACLI/R5Ae7YqMasYZQEQAhojRhHWHbf-UYBXQQCLcBGAsYHQ/s1600-rw-e90/%25D9%2585%25D8%25B6%25D8%25BA%25D9%2588%25D8%25B7%25D9%2587.png";
    }else{
        $first_img = $matches[1][0];
    }

    return $first_img;
}




require get_template_directory() . '/inc/walker.php';
function my_menus(){
    register_nav_menu( 'main-menu', 'my_min_menu' );
    register_nav_menu( 'top-pages', 'header_top_pages' );
    register_nav_menu( 'top-icons', 'header_top_icons' );
}
add_action( 'init', 'my_menus');






function post_sanpit_length($length){
return 15;
}
function post_sanpit_more($more){
return ' ...';
}
add_filter( 'excerpt_length', 'post_sanpit_length' );
add_filter( 'excerpt_more', 'post_sanpit_more' );






require get_template_directory() . '/inc/widgets.php';












// Disable standard WordPress widgets
add_action('widgets_init', 'unregister_basic_widgets' );

function unregister_basic_widgets() {

	unregister_widget('WP_Widget_Pages');           // Page widget
	unregister_widget('WP_Widget_Calendar');        // Calendar
	unregister_widget('WP_Widget_Archives');        // Archives
	unregister_widget('WP_Widget_Links');           // Links
	unregister_widget('WP_Widget_Meta');            // Meta widget
	unregister_widget('WP_Widget_Search');          // Search
	unregister_widget('WP_Widget_Text');            // Text
	// unregister_widget('WP_Widget_Categories');      // Categories
	unregister_widget('WP_Widget_Recent_Posts');    // Recent posts
	unregister_widget('WP_Widget_Recent_Comments'); // Recent comments
	unregister_widget('WP_Widget_RSS');             // RSS
	// unregister_widget('WP_Widget_Tag_Cloud');       // Tag cloud
	unregister_widget('WP_Nav_Menu_Widget');        // Menu
	unregister_widget('WP_Widget_Media_Audio');     // Audio
	unregister_widget('WP_Widget_Media_Video');     // Video
	unregister_widget('WP_Widget_Media_Gallery');   // Gallery
	unregister_widget('WP_Widget_Media_Image');     // Image
}









add_action( 'wp_ajax_nopriv_load_posts_by_ajax', 'theme_load_more' );
add_action( 'wp_ajax_load_posts_by_ajax', 'theme_load_more' );

function theme_load_more(){

    $ajax_page_id = $_POST['ajax_page_id'];
    $args = array(
        'post_type' => 'post',
        'posts_per_page' => '6', // عدد المقالات في كل صفحة
        'paged' => $ajax_page_id,
    );

    if($_POST['cat_id']){
        $ajax_id = $_POST['cat_id'];
        $args['cat'] =  $ajax_id;
    }elseif($_POST['tag_id']){
        $ajax_id = $_POST['tag_id'];
        $args['tag'] =  $ajax_id;
    }elseif($_POST['aut_id']){
        $ajax_id = $_POST['aut_id'];
        $args['author'] =  $ajax_id;
    }elseif($_POST['ser_id']){
        $ajax_id = $_POST['ser_id'];
        $args['s'] =  $ajax_id;
    }

    $my_posts = new WP_Query( $args );
    if ( $my_posts->have_posts() ) :
        while ( $my_posts->have_posts() ) : $my_posts->the_post();
            get_template_part('postsTemplate', null );
        endwhile;
    else:
        // echo "no more posts";
    endif;
    die();
}



// عرض إعلانات في منتصف وبعد كل فقرة
function insert_ads_in_content($content) {
    // تحقق مما إذا كانت الصفحة تحتوي على محتوى قابل للعرض
    if (is_single() || is_page()) {
        
        
        $userID = get_the_author_meta('ID');
        $userAds = getoptions('sp_author_ads');
        $userAdsU = $userAds['users'];

        $userAdsUID = $userAdsU[$userID];
        $userAdsUAActive = $userAdsUID['useractive'];

        
        $userAdsUARatio = isset($userAdsUID['custom_ratio']) ? $userAdsUID['custom_ratio'] : $userAds['author_ratio'];
        $userAdsUARandom = rand(0, 100);
        $userAdsAfterRatio = $userAdsUARandom < $userAdsUARatio && $userAdsUAActive;

        $ads = getoptions('sp_theme_ads');

        // تحقق من وجود بيانات الإعلانات وأنها غير فارغة
        if ($ads && isset($ads['adsactive']) && $ads['adsactive'] == 1 && isset($ads['userAds'])) {
            foreach ($ads['userAds'] as $ad) {
                // تحقق من نوع الإعلان ومكانه
                if (isset($ad['adtype']) && isset($ad['adlocation'])) {
                    $ad_code = '';

                    // تحقق من نوع الإعلان لإضافة الكود المناسب
                    if ($ad['adtype'] === 'adsense') {
                        if($userAdsAfterRatio){
                            $ad_code = '<div class="adsense-ad">اعلان ادسنس للكاتب</div>';
                        }else{
                            $ad_code = '<div class="adsense-ad">اعلان ادسنس</div>';
                        }
                    } elseif ($ad['adtype'] === 'customecode') {
                        if($userAdsAfterRatio){
                            $ad_code = '<div class="custom-ad">اعلان كود للكاتب</div>';
                        }else{
                            $ad_code = '<div class="custom-ad">' . wp_kses_post($ad['adcode']) . '</div>';
                        }
                    }

                    // إذا تم العثور على كود الإعلان، قم بإدراجه في المكان المناسب داخل المحتوى
                    if (!empty($ad_code)) {
                        switch ($ad['adlocation']) {
                            case 'ad_top':
                                // إدراج كود الإعلان في أعلى المحتوى
                                $content = $ad_code . $content;
                                break;
                            case 'ad_bot':
                                // إدراج كود الإعلان في أسفل المحتوى
                                $content .= $ad_code;
                                break;
                            case 'ad_p1':
                            case 'ad_p2':
                            case 'ad_p3':
                            case 'ad_p4':
                            case 'ad_p5':
                            case 'ad_p6':
                            case 'ad_p7':
                                // إدراج كود الإعلان بعد الفقرة المحددة
                                $ad_paragraph = (int) substr($ad['adlocation'], -1); // استخراج رقم الفقرة من اسم الإعلان
                                $position = strpos($content, '</p>', 0); // البحث عن نهاية الفقرة الأولى
                                for ($i = 1; $i < $ad_paragraph; $i++) {
                                    $position = strpos($content, '</p>', $position + 1); // البحث عن نهاية الفقرة التالية
                                }
                                if ($position !== false) {
                                    $content = substr_replace($content, $ad_code . '</p>', $position + 4, 0); // إدراج كود الإعلان بعد نهاية الفقرة
                                }
                                break;
                            case 'ad_h2':
                                // يمكنك إضافة الإعلانات للترويسة h2 هنا
                                break;
                            case 'ad_h3':
                                // يمكنك إضافة الإعلانات للترويسة h3 هنا
                                break;
                            case 'ad_h4':
                                // يمكنك إضافة الإعلانات للترويسة h4 هنا
                                break;
                            case 'ad_cent':
                                // إدراج كود الإعلان في منتصف المحتوى
                                $paragraphs = explode('</p>', $content);
                                $middle_position = ceil(count($paragraphs) / 2);
                                array_splice($paragraphs, $middle_position, 0, $ad_code . '</p>');
                                $content = implode('</p>', $paragraphs);
                                break;
                            // إضافة حالات إضافية إذا لزم الأمر
                        }
                    }
                }
            }
        }
    }

    return $content;
}

// قم بربط الوظيفة بالفلتر the_content
add_filter('the_content', 'insert_ads_in_content');



require get_template_directory() . '/admin/admin-page.php';
require get_template_directory() . '/admin/inclouded.php';
require get_template_directory() . '/admin/users_functions.php';






function my_custom_save_ads_txt_file() {
    // التحقق من أن المستخدم لديه صلاحيات التعديل
    if (!current_user_can('manage_options')) {
        return;
    }
    // التحقق من وجود بيانات POST ومن أن الصفحة المطلوبة صحيحة
    if (isset($_POST['_wp_http_referer']) && strpos(sanitize_text_field($_POST['_wp_http_referer']), 'seoplus_ads') !== false) {
        // جلب محتوى ads.txt من بيانات POST بعد تنظيفها

        $isActive = false;
        $file_content = '';

        if (isset($_POST['sp_ads_txt']['ads_text_area']) && !empty($_POST['sp_ads_txt']['ads_text_area'])) {
            $isActive = true;
            $file_content = sanitize_textarea_field($_POST['sp_ads_txt']['ads_text_area']);
        } elseif (isset($_POST['sp_theme_ads']['adsensepub']) && !empty($_POST['sp_theme_ads']['adsensepub'])) {
            // ادسنس الموقع الاساسي
            $isActive = true;

            $get_old_ads_txt = getoptions('sp_ads_txt');
            $adsense_client = sanitize_textarea_field($_POST['sp_theme_ads']['adsensepub']);

            $old_ads_client = !str_contains($get_old_ads_txt['ads_text_area'], $adsense_client);

            if (!empty($adsense_client) && $old_ads_client) {
                $new_ads_txt = "google.com, " . $adsense_client . ", DIRECT, f08c47fec0942fa0\n";
                $file_content = $new_ads_txt . $get_old_ads_txt['ads_text_area'] ;
                
                // تحديث الخيار
                $new_array = array(
                    'ads_text_active' => $get_old_ads_txt['ads_text_active'],
                    'ads_text_area' => $file_content,
                );
                
                // تحديث الخيار في قاعدة البيانات
                update_option('sp_ads_txt', $new_array);

                // تحديث الملف
            }

        }


        if($isActive){
            // تعديل المسار ليكون الطريق الكامل لملف ads.txt
            $file_path = ABSPATH . 'ads.txt';

            // التأكد من جاهزية نظام الملفات
            if (!function_exists('WP_Filesystem')) {
                require_once(ABSPATH . 'wp-admin/includes/file.php');
            }

            $creds = request_filesystem_credentials('', '', false, false, array());

            // التحقق من تهيئة نظام الملفات بنجاح
            if (!WP_Filesystem($creds)) {
                error_log('Failed to initialize WP_Filesystem');
                return; // إنهاء إذا لم يتم تهيئة النظام
            }

            // الحصول على كائن نظام الملفات
            global $wp_filesystem;

            // التحقق من أن $wp_filesystem هو كائن وليس قيمة false
            if (is_object($wp_filesystem) && $wp_filesystem->put_contents($file_path, $file_content, FS_CHMOD_FILE)) {
                error_log('Successfully updated ads.txt');
            } else {
                error_log('Failed to update ads.txt');
            }
        }

    }
}
add_action('admin_init', 'my_custom_save_ads_txt_file');




// add_action('admin_init', 'create_ads_txt_file');

// function create_ads_txt_file() {
        // $ads_txt_path = ABSPATH . 'ads.txt'; // مسار ملف ads.txt في الجذر الخاص بموقعك
        // // إنشاء محتوى الملف ads.txt هنا
        // $ads_txt_content = "google.com, pub-0000000000000000, DIRECT, f08c47fec0942fa0\n";
        // // إنشاء الملف
        // file_put_contents($ads_txt_path, $ads_txt_content);
//         // قم بإعلام المستخدم بنجاح الإنشاء
//         echo "تم إنشاء ملف ads.txt بنجاح.";

// }








/* شغل جديد فكرة بيبو */


// دالة للتحقق من الروابط وتحديث حالة المقال إذا كانت هناك روابط غير مسموح بها
function check_and_update_post_status($post_ID, $post, $update) {
    # تحقق من أن المستخدم ليس مديرًا
    if (current_user_can('administrator')) {
        return;
    }
    # تحقق من نوع المنشور (تجنب التحقق من الأنواع الأخرى غير المقالات)
    if ($post->post_type !== 'post') {
        return;
    }

    $users_mangment = getoptions('sp_users_mangment');
    $isActive = $users_mangment['users_mangment_is_active'];
    
    $author_id = $post->post_author;
    $excludedusers = $users_mangment['excludedusers'][$author_id]['useractive'];

    $isUserActive = isset($excludedusers) ? $excludedusers : false;

    # تحقق لو الاداة مش مفعله انشر بحرية
    if(!$isActive){
        return;
    }
    # تحقق لو المستخدم لديه صلاحيه للنشر بحريه
    if($isActive && $isUserActive){
        return;
    }



    

    // تحويل $allowed_domains إلى قائمة النطاقات فقط باستخدام parse_url
    $allowed_domains = getoptions('sp_users_mangment_white_list' , 'white_list');
    $allowed_domains[] = get_site_url();
    $allowed_domains = array_map(function($url) {
        $parsed_url = parse_url($url);
        return isset($parsed_url['host']) ? strtolower($parsed_url['host']) : strtolower($url);
    }, $allowed_domains);

    // جلب محتوى المقالة
    $post_content = get_post_field('post_content', $post_ID);

    // استخدام استعلامات RegExp لاستخراج الروابط
    $regex = '/<a[^>]*href="([^"]+)">[^<]*<\/a>/i';
    preg_match_all($regex, $post_content, $matches);

    // تحقق من وجود روابط خارجية غير مسموح بها
    $unauthorized_links = false;
    foreach ($matches[1] as $href) {
        $parsed_url = parse_url($href);
        $host = isset($parsed_url['host']) ? strtolower($parsed_url['host']) : strtolower($href);
        if (!in_array($host, $allowed_domains)) {
            $unauthorized_links = true;
            break;
        }
    }


    // إذا كانت هناك روابط غير مسموح بها، ضع النشر في "قيد المراجعة"
    if ($unauthorized_links) {
        // إزالة نفس العملية لتجنب حدوث حلقة
        remove_action('save_post', 'check_and_update_post_status');

        // تحديث حالة المقال إلى "قيد المراجعة"
        wp_update_post(array(
            'ID' => $post_ID,
            'post_status' => 'pending'
        ));

        add_filter('redirect_post_location', function($location) {
            return add_query_arg('unauthorized_links', 'true', $location);
        });

        // إعادة إضافة العملية بعد التحديث
        add_action('save_post', 'check_and_update_post_status', 10, 3);

    }


}

// تنفيذ دالة التحقق والتحديث عند حفظ المنشور
add_action('save_post', 'check_and_update_post_status', 10, 3);

add_action('admin_notices', function () {
    if (isset($_GET['unauthorized_links']) && $_GET['unauthorized_links'] == 'true') {
        echo '<style>.notice.notice-success.is-dismissible.updated { display: none; }</style><div class="notice notice-warning is-dismissible"><p>تم تحويل المقال إلى المراجعة بسبب وجود روابط خارجية غير مسموح بها.</p></div>';
    }
});





// إضافة الأعمدة الخاصة بالروابط الخارجية
add_filter('manage_posts_columns', function($column) {
    $isActive = getoptions('sp_users_mangment', 'users_mangment_tapel');
    if(!$isActive) return $column;
    if (!current_user_can('edit_others_posts')) return $column;

    $column['un-external-links'] = 'الروابط الخارجية';
    return $column;
});

// عرض الروابط الخارجية في الأعمدة الخاصة بها
add_filter('manage_posts_custom_column', function($column_name, $post_ID) {

    $isActive = getoptions('sp_users_mangment', 'users_mangment_tapel');
    if(!$isActive) return;
    if ($column_name != 'un-external-links') return;

    $post = get_post($post_ID);
    $post_content = $post->post_content;

    $regex = '/<a[^>]*href="([^"]+)">[^<]*<\/a>/i';
    preg_match_all($regex, $post_content, $match);

    $links_count = count($match[1]);

    if (!$links_count) {
        echo " <p style='color:white;font-size:11px;background-color:#666;border-radius:3px;margin:5px 0;text-align:center;padding:5px;'>
            لا يوجد روابط بالمقال
        </p> ";
    } else {
        $links_str = '';
        $siteurl = strtolower( parse_url(get_site_url())['host'] );

        $ex_links_count = 0;

        foreach ($match[1] as $val) {

            $link = strtolower(parse_url($val)['host']) ;

            if (str_contains($val, $siteurl) !== false) {
                $ex_links_count++;
            } else {

                $links_str .= " <p style='color:white;font-size:11px;background-color:#876200;border-radius:3px;margin:5px 0;text-align:center;padding:5px;'>
                    {$link}
                </p> ";

            }
        }
        if ($ex_links_count != $links_count && $ex_links_count > 0) {

            echo " {$links_str}
            <p style='color:white;font-size:11px;background-color:#54674f;border-radius:3px;margin:5px 0;text-align:center;padding:5px;'>
                و {$ex_links_count} من الروابط الداخلية 
            </p> ";

        } else {
            echo $links_str;
        }

        if ($ex_links_count == $links_count) {
            echo " <p style='color:white;font-size:11px;background-color:#54674f;border-radius:3px;margin:5px 0;text-align:center;padding:5px;'>
                جميع الروابط الداخلية وعددهم {$links_count}
            </p> ";
        }
    }
}, 10, 2);











// دالة الشورت كود
function pageredirect() {
    $redop = getoptions('sp_redirect');
    return "
<div id='pageredirect'>
    <div class='cLoaderWrap'>
        <svg id='cLoaderSVG' width='260' height='260' xmlns='http://www.w3.org/2000/svg'><circle class='cPath' r='110' cy='130' cx='130'></circle><circle class='cLoader' r='110' cy='130' cx='130'></circle><circle class='hLoader' r='110' cy='130' cx='130'></circle></svg>
        <b class='cCount'>".$redop['isTimer']."</b>
    </div>
    <div class='cButton'>
        <a class='cLink loder noredi' href='javascript:;' rel='nofollow noreferrer'>".$redop['textConfigure']."</a>
        <a  class='cLink ready hide noredi' rel='nofollow noreferrer' href='javascript:;'>".$redop['textReady']."</a>
        <a class='cLink err hide noredi' href='javascript:;' rel='nofollow noreferrer'>".$redop['textError']."</a>
    </div>
</div>
    ";
}

add_action('init', function(){
    add_shortcode('Sp_Redirect', 'pageredirect');
});









// function seoplus_check_for_update($checked_data) {
//     if (empty($checked_data->checked)) {
//         return $checked_data;
//     }

//     $request = wp_remote_get("https://raw.githubusercontent.com/ibrahemgit/sp_wordpress/main/update-check.json");

//     if (!is_wp_error($request) && wp_remote_retrieve_response_code($request) === 200) {
//         $response = json_decode(wp_remote_retrieve_body($request));
//         if (version_compare($response->new_version, $checked_data->checked['seoplus'], '>')) {
//             $checked_data->response['seoplus'] = array(
//                 'theme'       => 'seoplus',
//                 'new_version' => $response->new_version,
//                 'url'         => $response->url,
//                 'package'     => $response->package,
//             );
//         }
//     }

//     return $checked_data;
// }
// add_filter('pre_set_site_transient_update_themes', 'seoplus_check_for_update');

// function seoplus_push_update($transient) {
//     if (empty($transient->checked)) {
//         return $transient;
//     }

//     $request = wp_remote_get("https://raw.githubusercontent.com/ibrahemgit/sp_wordpress/main/update-check.json");

//     if (!is_wp_error($request) && wp_remote_retrieve_response_code($request) === 200) {
//         $response = json_decode(wp_remote_retrieve_body($request));
//         if (version_compare($response->new_version, $transient->checked['seoplus'], '>')) {
//             $transient->response['seoplus'] = array(
//                 'theme'       => 'seoplus',
//                 'new_version' => $response->new_version,
//                 'url'         => $response->url,
//                 'package'     => $response->package,
//             );
//         }
//     }

//     return $transient;
// }
// add_filter('site_transient_update_themes', 'seoplus_push_update');
