<?php get_header(); ?>

    <div class="container site">
        <div class="bocker">
            <main class="r-r potg">
                <div class="Tempnec"><!-- Main SECTION -->
                    <?php get_template_part('category-posts'); ?>
                </div><!-- Main SECTION -->
            </main>
            <aside class="potg btg2" id="sidepar-wid">
                <?php dynamic_sidebar('min-sidebar'); ?>
            </aside>
        </div>
    </div>

<?php get_footer(); ?>