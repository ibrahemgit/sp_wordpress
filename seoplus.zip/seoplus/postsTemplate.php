<article class="posts postnum<?php _e($args[0]); ?>">
    <a title="<?php the_title(); ?>" class="thumb Img-Loaded" href="<?php the_permalink(); ?>"><span class="postcat catnum<?php _e(rand(1,10)); ?>"><?php _e(get_the_category()[0]->cat_name); ?></span><?php post_post_image(); ?></a>
    <div class="cont">
        <span class="Date"><svg><use href="#ic-clock"></use></svg><time><?php the_time('F j, Y'); ?></time></span>
        <h3 class="rnav-title"><a title="<?php the_title(); ?>" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
        <div class="Short_content"><?php echo get_the_excerpt(); ?></div>
        <a class="moreLink" title="<?php the_title(); ?>" href="<?php the_permalink(); ?>">اقرأ المزيد</a>
    </div>
</article>