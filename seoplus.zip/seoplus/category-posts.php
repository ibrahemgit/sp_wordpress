<?php 
$lastStyle = getoptions("sp_lastPosts" , "style") ; ?>
<div class='widget MinWidget'>

    <div class="headline">
        <h1 class="title"> <?php 
        if(is_category()){
            single_cat_title('' , true );
        }elseif(is_tag()){
            single_term_title();
        }elseif(is_search()){
            echo get_search_query();
        }elseif(is_author()){
            $author_id = get_queried_object_id();
            echo get_the_author();
        }
         ?> </h1>
        <span class="line"></span>
    </div>

    <div class="<?php echo($lastStyle); ?>">
        <div class="Posts-byCategory">
            <?php

                if(is_category()){
                    $cat_id = get_queried_object_id();
                    $args = array(
                        'category__in' => array($cat_id),
                        'post_type' => 'post',
                        'posts_per_page' => '6', // عدد المقالات في كل صفحة
                    );
                }elseif(is_tag()){
                    $args = array(
                        'tag' => get_query_var('tag'),
                        'post_type'			=> 'post',
                        'posts_per_page' => '6', // عدد المقالات في كل صفحة
                    );
                }elseif(is_search()){
                    $args = array(
                        's' => get_search_query(),
                        'post_type'			=> 'post',
                        'posts_per_page' => '6', // عدد المقالات في كل صفحة
                    );
                }elseif(is_author()){
                    $args = array(
                        'author' => $author_id,
                        'post_type'			=> 'post',
                        'posts_per_page' => '6', // عدد المقالات في كل صفحة
                    );
                }

                $post_tag = new WP_Query($args);
                $posts_count = $post_tag->found_posts;
                if( $post_tag->have_posts() ): 
                    while($post_tag->have_posts()): $post_tag->the_post();
                        get_template_part('postsTemplate', null , array($post_tag->current_post));
                    endwhile;
                endif;
                wp_reset_query();


                // attributes
                if(is_category()){
                    $attributes = "data-cat='". get_queried_object()->term_id."' max-num='". $posts_count ."'";
                }elseif(is_tag()){
                    $attributes = "data-tag='". get_query_var('tag') ."' max-num='". $posts_count ."'";
                }elseif(is_search()){
                    $attributes = "data-search='". get_search_query() ."' max-num='". $posts_count ."'";
                }elseif(is_author()){
                    $attributes = "data-aut='". $author_id ."' max-num='". $posts_count ."'";
                }
            ?>
        </div>
        
        <div class="loadMore" <?php echo $attributes; ?>>
            <div id="loadMorePosts">تحميل المزيد من المشاركات</div>
            <div id="loadMoreWait"><span class="spiner-icon"></span>جاري التحميل ...</div>
            <div id="loadMoreNomore">لم يتم العثور على أي نتائج</div>
        </div>
    </div>
</div>