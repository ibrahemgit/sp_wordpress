<!DOCTYPE html>
<html lang="<?php bloginfo("language"); ?>" dir="<?php bloginfo("text_direction"); ?>">
    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <?php wp_head(); ?>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@500;700;800;900&display=swap" rel="stylesheet">

    </head>
    <body <?php body_class(); ?>><div class="sitecontain">

    <?php get_template_part( "headers/header", getoptions("sp_header", "HeaderStyle") ); ?>






<input class='navC hidden' id='NavC' type='checkbox' />
<div class='searchformbox'>
    <div class='fxbox'>
        <div id="searchform">
            <div class="widget BlogSearch" data-version="2" id="BlogSearch2">
                <form class='sharef' action='<?php echo get_home_url(); ?>' method="get" role='search' target='_top'>
                    <label class='sp' for="s">
                        <svg class='line'>
                            <use href='#ic-search' />
                        </svg>
                    </label>
                    <input autocomplete='off' aria-label='<?php echo get_search_query(); ?>' placeholder='بحث ...' value='<?php echo get_search_query(); ?>' id='s' minlength='3' name='s' required='required' type='search'>
                    <button aria-label='Clear' class='sp' data-text='حذف' type='reset'></button>
                </form>
                <label aria-label='Close' class='searchC' for='NavC' >
            </div>
            <div class="Label" id="Label002">
                <div class="headline"><h2 class="title">أقسام الوصول السريع</h2><span class="line"></span></div>
                <div class="widget-content cloud-label-widget-content">
                    <?php
                        $categories = array_slice(get_categories(), 0, 10);
                        foreach($categories as $category) {
                            echo '<span class="label-size"><a class="label-name" data-text="'.$category->name.'" href="'.get_category_link($category->term_id).'">'.$category->name.'<span class="label-count">'.$category->count.'</span></a></span>';
                        }
                    ?>
                </div>
            </div>
        </div>
    </div>
    <label class='fCls searchbg' for='NavC'>
</div>















<input class='navM hidden' id='NavM' type='checkbox'/>
<label aria-label='Close Menu' class='pos-t-t' for='NavM'></label>
<div class="sidenav">
    <div class="sidehead"><label aria-label="Close Menu" class="closemenu" for="NavM"></label></div>
    <div class="sidenavscroler">
        <div class="SiteInfo"></div>
        <div class="bottsocial"></div>
        <div class="flexmenu">
            <div class="mainmenu"></div>
            <div class="bottommeny">
                <div class="bottpage"></div>
            </div>
        </div>
    </div>
</div>