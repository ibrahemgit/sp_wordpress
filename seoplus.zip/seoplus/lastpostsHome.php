<?php 
$lastStyle = getoptions("sp_lastPosts" , "style") ; ?>
<div class='widget MinWidget'>

    <div class="headline">
        <h2 class="title">آخر المشاركات</h2>
        <span class="line"></span>
    </div>

    <div class="<?php echo($lastStyle); ?>">
        <div class="Posts-byCategory">
            <?php
                $args = array(
                    'post_type' => 'post',
                    'posts_per_page' => '6', // عدد المقالات في كل صفحة
                    'paged' => 1,
                );
                $post_tag = new WP_Query($args);
                $posts_count = $post_tag->found_posts;
                if( $post_tag->have_posts() ): 
                    while($post_tag->have_posts()): $post_tag->the_post();
                        get_template_part('postsTemplate', null , array($post_tag->current_post));
                    endwhile;
                endif;
                wp_reset_query();
            ?>
        </div>
        <div class="loadMore" max-num="<?php echo $posts_count; ?>">
            <div id="loadMorePosts">تحميل المزيد من المشاركات</div>
            <div id="loadMoreWait"><span class="spiner-icon"></span>جاري التحميل ...</div>
            <div id="loadMoreNomore">لم يتم العثور على أي نتائج</div>
        </div>
    </div>
</div>