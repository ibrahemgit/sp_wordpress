<div class="bobxed">
    <div class="foqTitle">
        <!-- <a class="postTopTag category" href="https://rtl-demo.seoplus-template.com/search/label/%D9%85%D8%AF%D9%86%20%D8%B9%D8%B1%D8%A8%D9%8A%D9%87" title="<?php echo get_the_category()[0]->cat_name; ?>" rel="tag"> <?php echo get_the_category()[0]->cat_name; ?> </a> -->
    </div>
    <h1 class="topic-title"><?php the_title(); ?></h1>
    <div class="post-meta">
        <div class="au-ti">
            <div class="article-author">
                <div class="metapost">
                    <address class="authorname Img-Loaded">
                        <?php echo get_avatar( get_the_author_meta('ID') ); ?>
                        <?php echo get_the_author(); ?>
                    </address>
                    <div class="article-timeago">
                        <svg><use href="#ic-clock-r"></use></svg>
                        <time class="agotime" ><?php the_time('F j, Y'); ?></time>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="post-body">
    <?php
        // echo getoptions('sp_ads_Settings' , 'ad_top');
            the_content(); 
        // echo getoptions('sp_ads_Settings' , 'ad_bot');
     ?>
</div>

<div class="hideensa">

    <!-- <div class="post-tags">
        <span class="tagstitle" data-text="الأقسام" ></span>
        <?php echo the_category( ' ' ); ?>
    </div> -->

    <!-- <div class="RelatedPosts">
        <div class="headline"><h3 class="title">اخر المقالات</h3></div>
        <div class="Sp-posts1"><div class="Posts-byCategory">
            <?php 
                $args = array(
                    'post_type'			=> 'post',
                    'posts_per_page'	=> 4,
                    'cat' => get_the_category()[0]->cat_ID,
                );
                $post_tag = new WP_Query($args);
                if( $post_tag->have_posts() ): 
                    while($post_tag->have_posts()): $post_tag->the_post();
                        get_template_part('postsTemplate' , null , array($post_tag->current_post)); 
                    endwhile;
                endif;
                wp_reset_query();
            ?>
        </div></div>
    </div> -->


</div>