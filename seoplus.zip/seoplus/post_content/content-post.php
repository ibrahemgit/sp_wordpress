<div class="bobxed">
    <div class="foqTitle">
        <a class="postTopTag category" href="<?php echo get_category_link( get_the_category()[0]->term_id ); ?>" title="<?php echo get_the_category()[0]->cat_name; ?>" rel="tag"> <?php echo get_the_category()[0]->cat_name; ?> </a>
    </div>
    <h1 class="topic-title"><?php the_title(); ?></h1>
    <div class="post-meta">
        <div class="au-ti">
            <div class="article-author">
                <div class="metapost">
                    <address class="authorname Img-Loaded">
                        <?php echo get_avatar( get_the_author_meta('ID') ); ?>
                        <a class="url" href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>" rel="author nofollow noopener" target="_blank"><?php echo get_the_author(); ?></a>
                    </address>
                    <div class="article-timeago">
                        <svg><use href="#ic-clock-r"></use></svg>
                        <time class="agotime" ><?php the_time('F j, Y'); ?></time>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="post-body">
    <?php
        // echo getoptions('sp_ads_Settings' , 'ad_top');
            // echo get_content_with_ads(); 
            the_content();
        // echo getoptions('sp_ads_Settings' , 'ad_bot');
     ?>
</div>

<div class="hideensa">

    <div class="post-tags">
        <span class="tagstitle" data-text="الأقسام" ></span>
        <?php echo the_category( ' ' ); ?>
    </div>

    <div class="RelatedPosts">
        <div class="headline"><h3 class="title">مقالات قد تهمك</h3></div>
        <div class="Sp-posts1"><div class="Posts-byCategory">
            <?php 
                $args = array(
                    'post_type'			=> 'post',
                    'posts_per_page'	=> 3,
                    'cat' => get_the_category()[0]->cat_ID,
                );
                $post_tag = new WP_Query($args);
                if( $post_tag->have_posts() ): 
                    while($post_tag->have_posts()): $post_tag->the_post();
                        get_template_part('postsTemplate' , null , array($post_tag->current_post)); 
                    endwhile;
                endif;
                wp_reset_query();
            ?>
        </div></div>
    </div>

    <div class='commentsection'>
    <?php
            if(comments_open()):
                comments_template();
            endif;
        ?>
    </div>

</div>