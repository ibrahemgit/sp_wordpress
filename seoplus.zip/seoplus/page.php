<?php get_header(); ?>

    <div class="container site">

        <div class="bocker">
            <main class="r-r potg">
                <div class="Tempnec post-amp post"><!-- Main SECTION -->
                    <?php
                    if( have_posts() ):
                        while(have_posts()): the_post(); 
                            get_template_part('post_content/content' , 'page');
                        endwhile;
                    endif;
                    ?>
                </div><!-- Main SECTION -->
            </main>
            <aside class="potg btg2" id="sidepar-wid">
                <?php dynamic_sidebar('min-sidebar'); ?>
            </aside>
        </div>

    </div>

<?php get_footer(); ?>