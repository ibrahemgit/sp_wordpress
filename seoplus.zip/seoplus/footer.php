<footer>
    <div class="container">
        <div class="mid-top-footer">
            <div class="footer-col" id="footer-col1"><?php dynamic_sidebar('sp-footer'); ?></div>
            <div class="footer-col" id="footer-col2"><?php dynamic_sidebar('sp-footer-2'); ?></div>
            <div class="footer-col" id="footer-col3"><?php dynamic_sidebar('sp-footer-3'); ?></div>
            <div class="footer-col" id="footer-col4"><?php dynamic_sidebar('sp-footer-4'); ?></div>
        </div>
    </div>

    <div class="bottom-footer" data-nosnippet="true">
        <div class="container">
            <div class="yemen">
            <span> جميع الحقوق محفوظة © </span><a href="<?php bloginfo( 'url' ) ?>" id="7qok" target="_blank"> <?php bloginfo( 'name' ) ?> </a>
            </div>
            <div class="shmal">
                <div id="footer-social">
                    <?php 
                    if (has_nav_menu('top-icons')) {
                        wp_nav_menu(array(
                            'theme_location' => 'top-icons',
                            'container' => false,
                            'depth' => 0,
                            'items_wrap' => '<ul class="social-static social">%3$s</ul>',
                            'walker' => new Social_Media_Walker_Nav_Primary()
                        ));
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</footer>

    <?php wp_footer(); ?>
    </div>
    <?php get_template_part( "icons" ); ?>
</body>
</html>