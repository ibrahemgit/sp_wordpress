<?php
    $homepg=get_bloginfo('url');
    header("Location: $homepg",TRUE,301);
?>