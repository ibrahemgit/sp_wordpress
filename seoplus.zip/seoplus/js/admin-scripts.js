

// first
jQuery('.sidebars-column-1>div, .sidebars-column-2>div').wrapAll('<div class="SeoplusWidgets"></div>').addClass('closed');

// second # sides
jQuery('#post_section-5, #post_section-6, #post_section-7, #post_section-8, #post_section-9, #post_section-10, #post_section-11, #post_section-12, #min-sidebar').parent().wrapAll("<div class='sides'></div>");

jQuery('#min-sidebar').parent().wrapAll("<div class='lside'></div>");

jQuery('#post_section-5, #post_section-6, #post_section-7, #post_section-8, #post_section-9, #post_section-10, #post_section-11, #post_section-12').parent().wrapAll("<div class='rside'></div>");

// therd

jQuery('#post_section, #post_section-2, #post_section-3, #post_section-4').parent().wrapAll("<div class='postByCatSection one'></div>");

jQuery('#post_section-5, #post_section-6, #post_section-7, #post_section-8').parent().wrapAll("<div class='postByCatSection tow'></div>");

jQuery('#post_section-9, #post_section-10, #post_section-11, #post_section-12').parent().wrapAll("<div class='postByCatSection tre'></div>");

jQuery('#post_section-13, #post_section-14, #post_section-15, #post_section-16').parent().wrapAll("<div class='postByCatSection four'></div>");

jQuery('#min-sidebar').parent().wrapAll("<div class='sideparSection'></div>");

jQuery('#sp_footer, #sp_footer-2, #sp_footer-3, #sp_footer-4').parent().wrapAll("<div class='footerSection'></div>");

// forth
jQuery('#post_section-2, #post_section-3, #post_section-4').parent().wrapAll("<div class='adlists treeLists'></div>");

jQuery('#post_section-13, #post_section-14, #post_section-15').parent().wrapAll("<div class='adlists treeLists'></div>");

jQuery('#post_section-6, #post_section-7').parent().wrapAll("<div class='adlists towLists'></div>");

jQuery('#post_section-10, #post_section-11').parent().wrapAll("<div class='adlists towLists'></div>");

jQuery('#sp_footer, #sp_footer-2, #sp_footer-3, #sp_footer-4').parent().wrapAll("<div class='adlists fourLists'></div>");

// fifth
jQuery('.wp-clearfix').addClass('oba');



jQuery(document).on('click', function() {


jQuery(document).on('change', '.articlesoruce', function() { 
    $thisval = jQuery(this).val();
    if($thisval == "byCategory"){
        jQuery(this).parent().parent().find('.getcats').show();
    }else{
        jQuery(this).parent().parent().find('.getcats').hide();
    }
});






jQuery('.sp_radio_input_wid .radio').each(function(){
    
    if(jQuery(this).is(':checked')){
        jQuery(this).parent().addClass('checked').siblings().removeClass('checked')
    }
    
    jQuery(document).on('click', '.sp_radio_input_wid .radio', function() {

        
        jQuery(this).parent().addClass('checked').siblings().removeClass('checked')

        $val = jQuery(this).val();
        $target = jQuery(this).parent().parent().parent().parent();
        
        if($val == "Sp-3colList"){
            $target.find('.articalelength input').val('9');
        }

        if($val == "Sp-slide" || $val == "Sp-slide2" || $val == "Sp-posts5"){
            $target.find('.articalelength input').val('5');
        }

        if($val == "Sp-slide4" || $val == "Sp-posts7" || $val == "Sp-posts1" || $val == "Sp-posts2"){
            $target.find('.articalelength input').val('3');
        }

        if($val == "Sp-slide3" || $val == "Sp-postsnew" || $val == "Sp-postsnew0" || $val == "Sp-posts3" || $val == "Sp-posts4" || $val == "Sp-posts6"){
            $target.find('.articalelength input').val('4');
        }

    })

})


});

jQuery(document).ready(function($){
    var mediaUploader;

    $('.uploadButton').on('click',function(e){
        e.preventDefault();
        $thisitem = $(this).parent();

        if(mediaUploader){
            mediaUploader.open();
            return;
        }

        mediaUploader = wp.media.frames.file_frame = wp.media({
            title: 'Choose Site Logo',
            button: {
                text: 'Choose Logo'
            },
            multiple: false
        });
        
        mediaUploader.on('select',function(){
            attachment = mediaUploader.state().get('selection').first().toJSON();
            $($thisitem).find('.imginput').val(attachment.url);
        })
        
        mediaUploader.open();
    });



    jQuery(document).on('change', 'label.switch input', function() {
        $value = $(this).is(":checked");
        if($value){
            $(this).parent().find('.hide').attr('value', 1);
        }else{
            $(this).parent().find('.hide').attr('value', 0);
        }
    })

    jQuery(document).on('click', '.settings_taps .tap', function () {
        $id = "#" +  $(this).data("id");
        $(this).addClass('active');
        $(this).siblings().removeClass('active');
        $($id).siblings('.settings_group').hide();
        $($id).fadeIn('slow');
    })
});

















