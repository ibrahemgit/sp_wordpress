window._$=function(a){var b=document.querySelectorAll(a);return 1<b.length?b:0==b.length?document.createDocumentFragment().childNodes:b[0]};


let Newscroll = 0;
window.addEventListener("scroll", () => {
    if (document.querySelector(".StikyHead")) {
        let a = document.querySelector("header.nac") ? "stk" : "activeDown",
            b = window.scrollY,
            c = _$(".sp-header");
        b > Newscroll ? c.classList.add(a) : b < Newscroll && c.classList.remove(a), 100 < (Newscroll = b) ? c.classList.add("active") : c.classList.remove("active")
    }
});








let load_more = document.querySelector('.loadMore');

if(load_more){

    if(load_more.hasAttribute("data-cat")){
        var wp_id = load_more.getAttribute("data-cat");
        var wp_push = "cat_id";
    }else if(load_more.hasAttribute("data-tag")){
        var wp_id = load_more.getAttribute("data-tag");
        var wp_push = "tag_id";
    }else if(load_more.hasAttribute("data-aut")){
        var wp_id = load_more.getAttribute("data-aut");
        var wp_push = "aut_id";
    }else if(load_more.hasAttribute("data-search")){
        var wp_id = load_more.getAttribute("data-search");
        var wp_push = "ser_id";
    }else{
        var wp_id = 0;
        var wp_push = "home_page";
    }
    
    
    let formData = new FormData();
    let currentPage = 2;
    let nowposts = 6;
    let allposts = load_more.getAttribute("max-num");

    
    formData.append( 'action', 'load_posts_by_ajax' );
    document.querySelector('#loadMorePosts').addEventListener('click', ()=>{
        loadMorePosts.style.display = "none";
        loadMoreWait.style.display = "block";

        formData.append( wp_push , wp_id );
        formData.append( "ajax_page_id" , currentPage );
    
     
        fetch( '/wp-admin/admin-ajax.php', {
            method: 'POST',
            body: formData,
        } ) // wrapped
        .then( res => res.text() )
        .then( data => {
            currentPage++;
            document.querySelector('.Tempnec .Posts-byCategory').insertAdjacentHTML('beforeend',data)
        } )
        
        loadMorePosts.style.display = "block";
        loadMoreWait.style.display = "none";
        
        nowposts = nowposts + 6;
        if(nowposts >= allposts){
            loadMorePosts.style.display = "none";
            loadMoreWait.style.display = "none";
            loadMoreNomore.style.display = "block";
        }
    })
}
    