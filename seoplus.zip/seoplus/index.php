<?php get_header(); 


?>

    <div class="container site">

        <div class='fullwide '><?php dynamic_sidebar( 'post_section' ); ?></div><!-- ADDED SECTIONS -->
        <div class="Treelists btg2 potg">
            <?php dynamic_sidebar( 'post_section-2' ); ?>
            <?php dynamic_sidebar( 'post_section-3' ); ?>
            <?php dynamic_sidebar( 'post_section-4' ); ?>
        </div><!-- ADDED SECTIONS -->

        <div class="bocker">
            <main class="r-r potg">

                <div class='contpotg'><!-- ADDED SECTIONS -->
                    <?php dynamic_sidebar( 'post_section-5' ); ?>
                        <div class='towcol btg2'>
                            <?php dynamic_sidebar( 'post_section-6' ); ?>
                            <?php dynamic_sidebar( 'post_section-7' ); ?>
                        </div>
                    <?php dynamic_sidebar( 'post_section-8' ); ?>
                </div><!-- ADDED SECTIONS -->

                <div class="Tempnec"><!-- Main SECTION -->
                    <?php get_template_part('lastpostsHome'); ?>
                </div><!-- Main SECTION -->

                <div class='contpotg'><!-- ADDED SECTIONS -->
                    <?php dynamic_sidebar( 'post_section-9' ); ?>
                    <div class='towcol btg2'>
                        <?php dynamic_sidebar( 'post_section-10' ); ?>
                        <?php dynamic_sidebar( 'post_section-11' ); ?>
                    </div>
                    <?php dynamic_sidebar( 'post_section-12' ); ?>
                </div><!-- ADDED SECTIONS -->

            </main>

            <aside class="potg btg2" id="sidepar-wid">
                <?php dynamic_sidebar('min-sidebar'); ?>
            </aside>
        </div>

        <div class="Treelists btg2 potg "><!-- ADDED SECTIONS -->
            <?php dynamic_sidebar( 'post_section-13' ); ?>
            <?php dynamic_sidebar( 'post_section-14' ); ?>
            <?php dynamic_sidebar( 'post_section-15' ); ?>
        </div>
        <div class='fullwide '><?php dynamic_sidebar( 'post_section-16' ); ?></div>
        <!-- ADDED SECTIONS -->
        
    </div>

<?php get_footer(); ?>