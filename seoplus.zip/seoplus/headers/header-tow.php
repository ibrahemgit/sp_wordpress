

<header class="sp-header" id="sp-header">
        <div class="HeaderBg">
            <!-- Headr top -->
            <div class="HeaderTOP">
                <div class="Headerplace">
                    <div class="HTOPC">
                        <div id="pages">
                            <?php 
                            if (has_nav_menu('top-pages')) {
                                wp_nav_menu(array(
                                    'theme_location' => 'top-pages',
                                    'container' => false,
                                    'depth' => 0,
                                ));
                            }
                            ?>
                        </div>
                        <div id="topsocialL">
                            <?php 
                            if (has_nav_menu('top-icons')) {
                                wp_nav_menu(array(
                                    'theme_location' => 'top-icons',
                                    'container' => false,
                                    'depth' => 0,
                                    'items_wrap' => '<ul class="social-static social">%3$s</ul>',
                                    'walker' => new Social_Media_Walker_Nav_Primary()
                                ));
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="HeaderBOT">
                <div class="HBOTC">
                    <label aria-label="القائمة الرئيسي" class="open nav1" for="NavM" id="navMopile" onclick="openSidenav()"><svg class="line" viewBox="0 0 24 24"><line x1="3" x2="21" y1="12" y2="12"></line><line x1="3" x2="21" y1="5" y2="5"></line><line x1="3" x2="21" y1="19" y2="19"></line></svg></label>
                    <div id="logo">
                        <?php if( !empty(getoptions('sp_header', 'logoUrl')) ) : ?>
                            <a class="img-logo" href="<?php bloginfo( 'url' ); ?>">
                                <img id="Header1_headerimg" src="<?php echo getoptions('sp_header', 'logoUrl'); ?>" alt="<?php bloginfo( 'name' ) ?>" />
                            </a>
                        <?php else : ?>
                            <h1 class='title'><a href="<?php bloginfo( 'url' ); ?>"><?php bloginfo( 'name' ) ?></a></h1>
                        <?php endif; ?>

                    </div>
                    <nav id='menu'>
                        <?php 
                        if (has_nav_menu('main-menu')) {
                            wp_nav_menu(array(
                                'theme_location' => 'main-menu',
                                'container' => false,
                                'menu_class' => 'nav navbar-nav navbar-right',
                                'walker' => new Seoplus_Walker_Nav_Primary()
                            ));
                        }
                        ?>
                    </nav>
                    <label aria-label='بحث' class='search' for='NavC' id='clicksearch'><svg class='line'><use href='#ic-search'></use></svg></label>
                </div>
            </div>
        </div>
    </header>