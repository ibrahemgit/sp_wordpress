<div class="headline"><h2 class="title"> التعليقات   </h2></div>

<div id="comments-respond">
    <?php comment_form(); ?>
</div>



<div class="comments-list">
    <?php
    // Get only the approved comments
        $args = array(
            'status' => 'approve',
            'post_id' => get_the_ID(),
            'parent'      => 0,
            'number'    => get_option( 'comments_per_page' ),
        );
            // echo "<pre>";
            // print_r($comments[15]);
            // echo "</pre>";
        // The comment Query
        $comments_query = new WP_Comment_Query();
        $comments       = $comments_query->query( $args );
        // Comment Loop
        if ( $comments ) {
            foreach ( $comments as $comment ) {

                $children = $comment->get_children();
                // echo "<pre>";
                // print_r($children);
                // echo "</pre>";
                ?>
                    <div class='comment' id='<?php echo 'comment-'.$comment->comment_ID; ?>'>
                        <div class="CommentCounter">
                            <div class="avatar-image"><?php echo get_avatar($comment->user_id); ?></span></div>
                            <div class="comment-block"><div class="cmt-user"> <?php echo $comment->comment_author ?> </div><p class="comment-content"><?php echo $comment->comment_content ?></p><div class="comment-actions"><a href='?replytocom=<?php echo $comment->comment_ID; ?>#respond' class="comment-reply">أترك ردا</a><a class="blog-admin" rel="nofollow noreferrer" target="_blank">حذف التعليق</a></div></div>
                        </div>
                        <div class="comment-replies">
                            <?php
                            foreach ( $children as $child ) {
                                ?>
                                <div class='comment' id='<?php echo 'comment-'.$child->comment_ID; ?>'><div class="CommentCounter">
                                    <div class="avatar-image"><?php echo get_avatar($child->user_id); ?></span></div>
                                    <div class="comment-block"><div class="cmt-user"> <?php echo $child->comment_author ?> </div><p class="comment-content"><?php echo $child->comment_content ?></p><div class="comment-actions"><a class="blog-admin" rel="nofollow noreferrer" target="_blank">حذف التعليق</a></div></div>
                                </div></div>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                <?php
            }
        }
    ?>

    <?php echo get_the_comments_navigation(); ?>
    
</div>

